import React, { useState } from "react";
import { SystemLog, UserProfile } from "../types";
import { ShieldAlert, Database, Terminal, Settings, ToggleLeft, Activity, RefreshCw } from "lucide-react";

interface AdminPanelProps {
  user: UserProfile;
  onUpdatePlan: (plan: "Free" | "Pro" | "Enterprise") => void;
  logs: SystemLog[];
  onClearLogs: () => void;
  theme: "light" | "dark";
}

export default function AdminPanel({
  user,
  onUpdatePlan,
  logs,
  onClearLogs,
  theme,
}: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState<"logs" | "settings">("logs");
  const [dbStatus, setDbStatus] = useState("Operational");
  const [apiRequests, setApiRequests] = useState(148);

  const triggerReset = () => {
    setApiRequests(0);
    onClearLogs();
  };

  return (
    <div className="flex-1 overflow-y-auto space-y-6 pr-1 h-full">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-sans font-extrabold tracking-tight">Ops Center & Admin</h2>
          <p className="text-xs text-zinc-500 font-medium">Monitor active server resources, inspect database volumes, and review API telemetry logs.</p>
        </div>

        <button
          onClick={triggerReset}
          className="px-3 py-1.5 border border-zinc-200 dark:border-zinc-800 rounded-xl text-xs font-semibold flex items-center gap-1 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition"
          id="btn-admin-reset"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Reset Server Metrics</span>
        </button>
      </div>

      {/* Resource meters */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className={`p-4 rounded-2xl border ${
          theme === "dark" ? "bg-zinc-900 border-zinc-800" : "bg-white border-zinc-200 shadow-sm"
        }`}>
          <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest block font-mono">Supabase Storage</span>
          <h3 className="text-lg font-bold font-sans mt-1">14.2 MB used</h3>
          <span className="text-[10px] text-zinc-500 mt-0.5 block">0.3% of 50GB Sandbox</span>
        </div>

        <div className={`p-4 rounded-2xl border ${
          theme === "dark" ? "bg-zinc-900 border-zinc-800" : "bg-white border-zinc-200 shadow-sm"
        }`}>
          <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest block font-mono">Gemini API Requests</span>
          <h3 className="text-lg font-bold font-mono mt-1">{apiRequests} callings</h3>
          <span className="text-[10px] text-emerald-500 mt-0.5 block">Health: Excellent (100%)</span>
        </div>

        <div className={`p-4 rounded-2xl border ${
          theme === "dark" ? "bg-zinc-900 border-zinc-800" : "bg-white border-zinc-200 shadow-sm"
        }`}>
          <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest block font-mono">Active user sessions</span>
          <h3 className="text-lg font-bold font-sans mt-1">1 active pool</h3>
          <span className="text-[10px] text-zinc-500 mt-0.5 block">Linked to: Suresh Kumar</span>
        </div>

        <div className={`p-4 rounded-2xl border border-indigo-500/20 bg-indigo-500/5`}>
          <span className="text-[10px] font-bold text-indigo-500 uppercase tracking-widest block font-mono">Supabase database</span>
          <h3 className="text-lg font-bold font-sans mt-1 text-indigo-600 dark:text-indigo-400">{dbStatus}</h3>
          <span className="text-[10px] text-zinc-500 mt-0.5 block">Connection latency: 2ms</span>
        </div>
      </div>

      {/* Main operational tabs */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Double Panel: Live Terminal Logs */}
        <div className={`lg:col-span-2 border rounded-2xl overflow-hidden ${
          theme === "dark" ? "bg-zinc-900 border-zinc-800" : "bg-white border-zinc-200 shadow-sm"
        }`}>
          <div className="p-4 border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <Terminal className="w-4 h-4 text-indigo-500" />
              <h3 className="font-sans font-bold text-xs uppercase tracking-wider text-zinc-400">Server stdout logs</h3>
            </div>
            <span className="text-[9px] font-mono font-bold bg-zinc-500/15 text-zinc-400 px-2 py-0.5 rounded">
              REAL-TIME
            </span>
          </div>

          <div className="p-4 bg-zinc-950 text-zinc-300 font-mono text-[10.5px] leading-relaxed space-y-2 h-[260px] overflow-y-auto">
            {logs.map((log) => (
              <div key={log.id} className="flex gap-2">
                <span className="text-zinc-500 flex-shrink-0">[{log.timestamp}]</span>
                <span className={`flex-shrink-0 font-bold ${
                  log.type === "success" ? "text-emerald-500" : log.type === "warning" ? "text-amber-500" : "text-indigo-400"
                }`}>
                  {log.service}:
                </span>
                <span className="text-zinc-300">{log.message}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Right Panel: Account overrides */}
        <div className={`p-5 rounded-2xl border space-y-4 ${
          theme === "dark" ? "bg-zinc-900 border-zinc-800" : "bg-white border-zinc-200 shadow-sm"
        }`}>
          <div className="flex items-center gap-1.5 border-b pb-2">
            <Settings className="w-4 h-4 text-indigo-500" />
            <h3 className="font-sans font-extrabold text-sm tracking-tight">System Controls</h3>
          </div>

          <div className="space-y-4 text-xs">
            {/* Override Plan Level */}
            <div className="space-y-1.5">
              <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-400 font-mono">
                Force Tenant Package Override
              </label>
              <div className="grid grid-cols-3 gap-1.5">
                {["Free", "Pro", "Enterprise"].map((plan) => (
                  <button
                    key={plan}
                    onClick={() => onUpdatePlan(plan as any)}
                    className={`py-2 rounded-xl border text-[10px] font-bold transition ${
                      user.plan === plan
                        ? "bg-indigo-600 border-indigo-600 text-white shadow"
                        : theme === "dark"
                          ? "bg-zinc-950 border-zinc-800 text-zinc-400 hover:bg-zinc-900"
                          : "bg-zinc-50 border-zinc-200 text-zinc-600 hover:bg-zinc-100"
                    }`}
                  >
                    {plan}
                  </button>
                ))}
              </div>
              <p className="text-[9px] text-zinc-500 leading-normal pt-1">
                Force override the current corporate session tier instantly to unlock Pro/Enterprise SDK features.
              </p>
            </div>

            {/* Sandbox Database Overrides */}
            <div className="space-y-1.5 border-t border-zinc-200 dark:border-zinc-800 pt-3">
              <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-400 font-mono">
                Database Sandbox Mode
              </label>
              <div className="flex items-center justify-between p-2 rounded-xl bg-zinc-500/5 border border-zinc-500/10">
                <span className="font-semibold text-[11px] text-zinc-500">Supabase Connection Link</span>
                <span className="text-[9.5px] font-bold text-indigo-500 uppercase font-mono">SIMULATED ACTIVE</span>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
