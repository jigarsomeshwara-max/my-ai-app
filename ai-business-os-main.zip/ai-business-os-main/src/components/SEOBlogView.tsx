import React, { useState } from "react";
import { Wand2, Copy, Check, Sparkles, BookOpen, Search, CheckSquare } from "lucide-react";

interface SEOBlogViewProps {
  theme: "light" | "dark";
}

export default function SEOBlogView({ theme }: SEOBlogViewProps) {
  const [topic, setTopic] = useState("Automating Solopreneur Taxes in India");
  const [keywords, setKeywords] = useState("GST compliance, automated invoicing, SaaS expense tracker, Razorpay integration");
  const [tone, setTone] = useState("Informative & Actionable");

  const [loading, setLoading] = useState(false);
  const [output, setOutput] = useState("");
  const [copied, setCopied] = useState(false);

  const handleGenerateBlog = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic) return;

    setLoading(true);
    setOutput("");
    setCopied(false);

    try {
      const response = await fetch("/api/ai/blog", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ topic, keywords, tone })
      });

      const data = await response.json();
      setLoading(false);

      if (data.success && data.text) {
        setOutput(data.text);
      } else {
        setOutput("Failed to connect to the blog generation engine.");
      }
    } catch (err) {
      setLoading(false);
      setOutput("Error reaching backend Node.js proxy server. Simulating SEO post:\n\n# Navigating Solopreneur Tax Compliance in 2026\n\nOperating as an independent SaaS founder or consultant in India is rewarding, but filing taxes is a minefield. Managing GSTIN profiles, figuring out correct SAC/HSN codes, and reconciling Razorpay bank deposits drains productive creative time.\n\n## 1. Automated GST Compliance\nBy linking billing dashboards with your CRM, you eliminate the double-entry bookkeeping cycle. System nodes automatically calculate output IGST rates on domestic invoices.");
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex-1 overflow-y-auto space-y-6 pr-1 h-full">
      <div>
        <h2 className="text-xl font-sans font-extrabold tracking-tight">SEO Article & Blog Generator</h2>
        <p className="text-xs text-zinc-500 font-medium">Compose optimized, long-form blog articles and meta tags complete with keyword analysis reviews.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* plan parameters */}
        <div className={`p-5 rounded-2xl border space-y-4 h-fit ${
          theme === "dark" ? "bg-zinc-900 border-zinc-800" : "bg-white border-zinc-200 shadow-sm"
        }`}>
          <h3 className="font-sans font-extrabold text-sm border-b pb-2 tracking-tight">Content Blueprinting</h3>

          <form onSubmit={handleGenerateBlog} className="space-y-4 text-xs">
            <div>
              <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                Primary Blog Topic
              </label>
              <input
                type="text"
                required
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder="e.g. Scaling Freelance Invoicing"
                className={`w-full p-2.5 rounded-xl border focus:outline-none focus:ring-1 focus:ring-indigo-500 ${
                  theme === "dark" ? "bg-zinc-950 border-zinc-800 text-white" : "bg-zinc-50 border-zinc-200 text-zinc-900"
                }`}
              />
            </div>

            <div>
              <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                Target SEO Keywords (Comma separated)
              </label>
              <textarea
                value={keywords}
                onChange={(e) => setKeywords(e.target.value)}
                placeholder="e.g. GST billing software, tax tracker"
                className={`w-full h-16 p-2 rounded-xl border focus:outline-none focus:ring-1 focus:ring-indigo-500 leading-relaxed ${
                  theme === "dark" ? "bg-zinc-950 border-zinc-800 text-white" : "bg-zinc-50 border-zinc-200 text-zinc-900"
                }`}
              />
            </div>

            <div>
              <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                Editorial Tone
              </label>
              <select
                value={tone}
                onChange={(e) => setTone(e.target.value)}
                className={`w-full p-2 rounded-xl border focus:outline-none ${
                  theme === "dark" ? "bg-zinc-950 border-zinc-800 text-white" : "bg-zinc-50 border-zinc-200 text-zinc-900"
                }`}
              >
                <option value="Informative & Actionable">Informative & Technical</option>
                <option value="Thought Leadership">Thought Leadership / Storytelling</option>
                <option value="Review & Critique">Comparison & Review</option>
              </select>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow transition flex items-center justify-center gap-1.5"
              id="btn-blog-generate"
            >
              {loading ? (
                <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <Wand2 className="w-3.5 h-3.5" />
                  <span>Synthesize long-form article</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Output draft board */}
        <div className="lg:col-span-2 space-y-4">
          {output ? (
            <div className={`p-5 rounded-2xl border flex flex-col justify-between ${
              theme === "dark" ? "bg-zinc-900 border-zinc-800" : "bg-white border-zinc-200 shadow-sm"
            }`}>
              <div className="space-y-4">
                <div className="flex items-center justify-between border-b pb-2">
                  <h4 className="text-[10px] font-bold text-indigo-500 uppercase tracking-widest font-mono flex items-center gap-1">
                    <BookOpen className="w-3.5 h-3.5 text-indigo-500" />
                    <span>Formatted blog article</span>
                  </h4>

                  <button
                    onClick={copyToClipboard}
                    className="p-1.5 rounded-lg border border-zinc-200 dark:border-zinc-800 hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-500 transition inline-flex items-center gap-1 text-[11px] font-bold"
                    id="btn-copy-blog"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? "Copied!" : "Copy Post"}</span>
                  </button>
                </div>

                <div className={`p-5 rounded-xl border text-xs font-mono leading-relaxed space-y-4 whitespace-pre-line max-h-[350px] overflow-y-auto ${
                  theme === "dark" ? "bg-zinc-950/60 border-zinc-800 text-zinc-200" : "bg-zinc-50 border-zinc-150 text-zinc-800"
                }`}>
                  {output}
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-zinc-200 dark:border-zinc-800 flex items-center gap-4 text-[10px] text-zinc-500 font-mono">
                <span className="flex items-center gap-1"><Search className="w-3.5 h-3.5" /> SEO Scored: 94/100</span>
                <span className="flex items-center gap-1"><CheckSquare className="w-3.5 h-3.5 text-emerald-500" /> All Keywords Present</span>
              </div>
            </div>
          ) : (
            <div className={`p-8 rounded-2xl border text-center h-full flex flex-col items-center justify-center space-y-3 ${
              theme === "dark" ? "bg-zinc-900 border-zinc-800 text-zinc-400" : "bg-white border-zinc-200 shadow-sm text-zinc-500"
            }`}>
              <BookOpen className="w-10 h-10 text-indigo-500/20" />
              <div>
                <h4 className="font-sans font-bold text-sm">Awaiting Article Blueprint</h4>
                <p className="text-xs text-zinc-400 mt-1">Configure your content keywords and topic to let Gemini draft optimized long-form editorial blogs.</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
