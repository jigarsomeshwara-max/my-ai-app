import { ClientCRM, Invoice, Expense, SystemLog } from "./types";

export const INITIAL_CLIENTS: ClientCRM[] = [
  {
    id: "crm-1",
    name: "Aarav Sharma",
    email: "aarav.sharma@zenithcorp.in",
    phone: "+91 98765 43210",
    company: "Zenith Solutions",
    value: 125000,
    status: "Qualified",
    notes: "Very interested in automating their custom logistics billing. Needs an invoice dashboard with custom GST parameters.",
    lastActive: "2026-07-02",
    insights: "AI SUGGESTION: Aarav responds well to high-level compliance proofing. Offer to build their specific HSN/SAC mappings as a visual asset. Follow up with a secure trial link."
  },
  {
    id: "crm-2",
    name: "Priyanka Patel",
    email: "priyanka.p@apexglobal.com",
    phone: "+91 87654 32109",
    company: "Apex Global Trading",
    value: 450000,
    status: "Warm",
    notes: "Expressed concern about syncing Razorpay webhooks directly to automated invoicing. Set up demo to show webhook stability.",
    lastActive: "2026-07-01",
    insights: "AI SUGGESTION: Lead is worried about technical failovers. Frame the next demo around standard retry logic and transaction auditing queues. Offer a 10% first-year contract discount."
  },
  {
    id: "crm-3",
    name: "Rohan Das",
    email: "rohan@dasdesign.co",
    phone: "+91 76543 21098",
    company: "Das Creative Studio",
    value: 45000,
    status: "Closed",
    notes: "Design studio. Subscription completed. Invoices fully reconciled on their portal.",
    lastActive: "2026-06-28"
  },
  {
    id: "crm-4",
    name: "Neha Iyer",
    email: "neha.iyer@cloudspace.co.in",
    phone: "+91 99887 76655",
    company: "CloudSpace Hosting",
    value: 300000,
    status: "Lead",
    notes: "Found through LinkedIn. Looking for a CRM that natively links client accounts with recurring automated invoice reminders.",
    lastActive: "2026-07-02"
  },
  {
    id: "crm-5",
    name: "Vikram Malhotra",
    email: "vikram@malhotrawarehouses.com",
    phone: "+91 91234 56789",
    company: "Malhotra Warehouse Logistics",
    value: 180000,
    status: "Contacted",
    notes: "Requested technical documentation for their in-house developer to review our REST API endpoints.",
    lastActive: "2026-06-30"
  }
];

export const INITIAL_INVOICES: Invoice[] = [
  {
    id: "inv-1",
    invoiceNumber: "INV-2026-001",
    clientName: "Zenith Solutions",
    clientEmail: "billing@zenithcorp.in",
    clientGstin: "27AAAAA1111A1Z1",
    date: "2026-06-20",
    dueDate: "2026-07-20",
    items: [
      { id: "item-1", description: "AI Platform Custom Integration", quantity: 1, rate: 85000 },
      { id: "item-2", description: "Cloud Hosting & Operational Node setup", quantity: 1, rate: 20000 }
    ],
    gstRate: 18,
    discount: 5000,
    status: "Paid",
    total: 118000
  },
  {
    id: "inv-2",
    invoiceNumber: "INV-2026-002",
    clientName: "Das Creative Studio",
    clientEmail: "billing@dasdesign.co",
    clientGstin: "19BBBBB2222B2Z2",
    date: "2026-06-25",
    dueDate: "2026-07-25",
    items: [
      { id: "item-3", description: "Monthly CRM & Invoicing SaaS License", quantity: 3, rate: 12000 }
    ],
    gstRate: 18,
    discount: 0,
    status: "Paid",
    total: 42480
  },
  {
    id: "inv-3",
    invoiceNumber: "INV-2026-003",
    clientName: "Apex Global Trading",
    clientEmail: "finance@apexglobal.com",
    clientGstin: "29CCCCC3333C3Z3",
    date: "2026-07-01",
    dueDate: "2026-07-31",
    items: [
      { id: "item-4", description: "Enterprise Marketing Automation Suite", quantity: 1, rate: 150000 },
      { id: "item-5", description: "SEO Blog Setup & Keywords Modeling", quantity: 1, rate: 50000 }
    ],
    gstRate: 18,
    discount: 15000,
    status: "Unpaid",
    total: 218300
  }
];

export const INITIAL_EXPENSES: Expense[] = [
  {
    id: "exp-1",
    amount: 14900,
    category: "Software Subscription",
    vendor: "Vercel Enterprise",
    date: "2026-06-15",
    gstRate: 18,
    gstAmount: 2272.88,
    description: "Cloud edge runtime node hosting subscriptions",
    tags: ["infrastructure", "hosting"]
  },
  {
    id: "exp-2",
    amount: 22500,
    category: "Marketing",
    vendor: "Google Ads",
    date: "2026-06-28",
    gstRate: 18,
    gstAmount: 3432.20,
    description: "SaaS lead generation search engine campaign",
    tags: ["marketing", "ads"]
  },
  {
    id: "exp-3",
    amount: 8200,
    category: "Office Supplies",
    vendor: "Croma Retail",
    date: "2026-07-02",
    gstRate: 18,
    gstAmount: 1250.84,
    description: "Wireless presentation clickers & hub adaptors",
    tags: ["office", "electronics"]
  }
];

export const INITIAL_LOGS: SystemLog[] = [
  { id: "log-1", timestamp: "23:00:15", type: "info", service: "AUTH", message: "Supabase User session validated successfully." },
  { id: "log-2", timestamp: "23:01:04", type: "success", service: "PAYMENT", message: "Razorpay Webhook: Payment ID pay_XYZ987 captured (₹42,480)." },
  { id: "log-3", timestamp: "23:01:10", type: "info", service: "GEMINI", message: "AI Context Prompt loaded. Processing chat summary for Priynaka Patel." },
  { id: "log-4", timestamp: "23:02:22", type: "warning", service: "NOTIFY", message: "FCM Push Token refreshing for registered iOS node." },
  { id: "log-5", timestamp: "23:02:35", type: "success", service: "DATABASE", message: "Supabase CRM Table synchronization complete. 0 conflicts resolved." }
];

// --- SDK CODE STRINGS ---

export const FLUTTER_PUBSPEC = `name: ai_business_os
description: A Production-Ready AI Business Operating System.
version: 1.0.0+1

environment:
  sdk: ">=3.0.0 <4.0.0"

dependencies:
  flutter:
    sdk: flutter
  cupertino_icons: ^1.0.5
  
  # Supabase client SDK
  supabase_flutter: ^2.4.0
  
  # State management & Routing
  provider: ^6.1.1
  go_router: ^13.2.0
  
  # Networking & HTTP
  http: ^1.2.0
  
  # Razorpay integration
  razorpay_flutter: ^1.3.5
  
  # Firebase Messaging
  firebase_core: ^2.27.0
  firebase_messaging: ^14.7.10
  
  # UI & Animation
  google_fonts: ^6.1.0
  flutter_spinkit: ^5.2.0
  fl_chart: ^0.66.0
  file_picker: ^8.0.0
  share_plus: ^7.2.1

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^3.0.0
`;

export const SUPABASE_SQL_SCHEMA = `-- ==========================================
-- AI BUSINESS OS - SUPABASE SYSTEM SCHEMA
-- ==========================================

-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- 1. PROFILES TABLE (Linked with Auth.users)
create table public.profiles (
  id uuid references auth.users on delete cascade primary key,
  updated_at timestamp with time zone,
  name text,
  company_name text,
  company_gstin text,
  plan text default 'Free' check (plan in ('Free', 'Pro', 'Enterprise')),
  avatar_url text
);

alter table public.profiles enable row level security;

create policy "Users can view their own profile" on public.profiles
  for select using (auth.uid() = id);
create policy "Users can update their own profile" on public.profiles
  for update using (auth.uid() = id);

-- 2. CRM CUSTOMERS TABLE
create table public.customers (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  name text not null,
  email text,
  phone text,
  company text,
  value numeric(12, 2) default 0.00,
  status text default 'Lead' check (status in ('Lead', 'Contacted', 'Warm', 'Qualified', 'Closed')),
  notes text,
  last_active timestamp with time zone default now(),
  ai_insights text
);

alter table public.customers enable row level security;

create policy "Users can manage their own customers" on public.customers
  for all using (auth.uid() = user_id);

-- 3. INVOICES TABLE
create table public.invoices (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  invoice_number text not null,
  client_name text not null,
  client_email text not null,
  client_gstin text,
  date date not null default current_date,
  due_date date not null,
  gst_rate numeric(4, 2) default 18.00,
  discount numeric(12, 2) default 0.00,
  status text default 'Unpaid' check (status in ('Paid', 'Unpaid', 'Overdue')),
  total numeric(12, 2) not null,
  created_at timestamp with time zone default now()
);

-- INVOICE ITEMS TABLE
create table public.invoice_items (
  id uuid default gen_random_uuid() primary key,
  invoice_id uuid references public.invoices(id) on delete cascade not null,
  description text not null,
  quantity integer not null default 1,
  rate numeric(12, 2) not null
);

alter table public.invoices enable row level security;
alter table public.invoice_items enable row level security;

create policy "Users can manage their own invoices" on public.invoices
  for all using (auth.uid() = user_id);
create policy "Users can manage items of their invoices" on public.invoice_items
  for all using (
    exists (
      select 1 from public.invoices 
      where public.invoices.id = public.invoice_items.invoice_id 
      and public.invoices.user_id = auth.uid()
    )
  );

-- 4. EXPENSES TABLE
create table public.expenses (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  amount numeric(12, 2) not null,
  category text not null,
  vendor text not null,
  date date not null default current_date,
  gst_rate numeric(4, 2) default 0.00,
  gst_amount numeric(12, 2) default 0.00,
  description text,
  tags text[],
  created_at timestamp with time zone default now()
);

alter table public.expenses enable row level security;

create policy "Users can manage their own expenses" on public.expenses
  for all using (auth.uid() = user_id);
`;

export const FLUTTER_SUPABASE_SERVICE = `import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class SupabaseService extends ChangeNotifier {
  final SupabaseClient _client = Supabase.instance.client;

  User? get currentUser => _client.auth.currentUser;
  bool get isAuthenticated => currentUser != null;

  // --- Auth Methods ---
  Future<void> signUp(String email, String password, {required String name, required String company}) async {
    final response = await _client.auth.signUp(
      email: email,
      password: password,
      data: {'name': name, 'company_name': company},
    );
    notifyListeners();
  }

  Future<void> signIn(String email, String password) async {
    await _client.auth.signInWithPassword(email: email, password: password);
    notifyListeners();
  }

  Future<void> signInWithGoogle() async {
    await _client.auth.signInWithOAuth(
      OAuthProvider.google,
      redirectTo: kIsWeb ? null : 'io.supabase.aibusinessos://login-callback/',
    );
    notifyListeners();
  }

  Future<void> signOut() async {
    await _client.auth.signOut();
    notifyListeners();
  }

  // --- Invoice Data Methods ---
  Future<List<Map<String, dynamic>>> fetchInvoices() async {
    final response = await _client
        .from('invoices')
        .select('*, invoice_items(*)')
        .order('created_at', ascending: false);
    return List<Map<String, dynamic>>.from(response);
  }

  Future<void> createInvoice(Map<String, dynamic> invoice, List<Map<String, dynamic>> items) async {
    final user = currentUser;
    if (user == null) return;

    final invoiceData = {
      ...invoice,
      'user_id': user.id,
    };

    final insertedInvoice = await _client.from('invoices').insert(invoiceData).select().single();
    final invoiceId = insertedInvoice['id'];

    final itemsData = items.map((item) => {
      ...item,
      'invoice_id': invoiceId,
    }).toList();

    await _client.from('invoice_items').insert(itemsData);
    notifyListeners();
  }

  // --- Expense Tracking ---
  Future<List<Map<String, dynamic>>> fetchExpenses() async {
    final response = await _client.from('expenses').select().order('date', ascending: false);
    return List<Map<String, dynamic>>.from(response);
  }

  Future<void> logExpense(Map<String, dynamic> expense) async {
    final user = currentUser;
    if (user == null) return;

    await _client.from('expenses').insert({
      ...expense,
      'user_id': user.id,
    });
    notifyListeners();
  }
}
`;

export const FLUTTER_GEMINI_SERVICE = `import 'dart:convert';
import 'package:http/http.dart' as http;

class GeminiService {
  // Point to your hosted backend proxy endpoint to protect your key!
  static const String _backendBaseUrl = "https://your-express-backend.com/api";

  Future<String> askCoPilot(String message, List<Map<String, String>> history) async {
    try {
      final response = await http.post(
        Uri.parse('$_backendBaseUrl/ai/chat'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'message': message,
          'history': history,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['text'] ?? "No response content.";
      }
      return "Error: Server returned status \${response.statusCode}";
    } catch (e) {
      return "Failed to contact AI Co-Pilot: $e";
    }
  }

  Future<Map<String, dynamic>> scanReceiptText(String receiptText) async {
    try {
      final response = await http.post(
        Uri.parse('$_backendBaseUrl/ai/expense-scanner'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'text': receiptText}),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'] ?? {};
      }
      throw Exception("Server failed with status \${response.statusCode}");
    } catch (e) {
      return {'error': e.toString()};
    }
  }
}
`;
