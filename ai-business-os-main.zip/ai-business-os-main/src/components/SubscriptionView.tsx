import React, { useState } from "react";
import { UserProfile } from "../types";
import { Check, ShieldCheck, Sparkles, AlertCircle, CreditCard, Landmark, Wallet, Eye, X } from "lucide-react";

interface SubscriptionViewProps {
  user: UserProfile;
  onUpdatePlan: (plan: "Free" | "Pro" | "Enterprise") => void;
  theme: "light" | "dark";
}

export default function SubscriptionView({ user, onUpdatePlan, theme }: SubscriptionViewProps) {
  const [showRazorpay, setShowRazorpay] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<"Free" | "Pro" | "Enterprise" | null>(null);
  const [priceToPay, setPriceToPay] = useState(0);

  // checkout form states
  const [cardNo, setCardNo] = useState("4111 2222 3333 4444");
  const [cardExpiry, setCardExpiry] = useState("12/28");
  const [cardCvv, setCardCvv] = useState("123");
  const [processing, setProcessing] = useState(false);
  const [success, setSuccess] = useState(false);

  const PLANS = [
    {
      name: "Free",
      price: "₹0",
      numericPrice: 0,
      description: "Ideal for fresh freelancers validating their business cashflow pipelines.",
      features: [
        "Up to 3 GST Invoices / month",
        "Basic manual Expense tracking",
        "5 AI chat co-pilot prompts",
        "Local session persistence only",
      ]
    },
    {
      name: "Pro",
      price: "₹1,499",
      numericPrice: 1499,
      description: "Perfect for active solopreneurs needing comprehensive AI tools & CRM.",
      features: [
        "Unlimited custom GST invoices",
        "AI OCR receipt scanner modules",
        "Generative SEO blog suite",
        "Lead acquisition follow-up scripts",
        "Standard developer SDK exports",
      ]
    },
    {
      name: "Enterprise",
      price: "₹4,999",
      numericPrice: 4999,
      description: "For agencies and teams requiring multi-user backends and advanced analytics.",
      features: [
        "Everything in Pro tier",
        "Advanced executive audit reports",
        "Custom SAC/HSN compliance maps",
        "Supabase Auth & Spanner schema exports",
        "Dedicated account strategist node",
      ]
    }
  ];

  const triggerCheckout = (planName: "Free" | "Pro" | "Enterprise", price: number) => {
    if (planName === "Free") {
      onUpdatePlan("Free");
      return;
    }
    setSelectedPlan(planName);
    setPriceToPay(price);
    setShowRazorpay(true);
    setSuccess(false);
    setProcessing(false);
  };

  const handleRazorpayPayment = (e: React.FormEvent) => {
    e.preventDefault();
    setProcessing(true);

    setTimeout(() => {
      setProcessing(false);
      setSuccess(true);
      setTimeout(() => {
        if (selectedPlan) {
          onUpdatePlan(selectedPlan);
        }
        setShowRazorpay(false);
      }, 1000);
    }, 1500);
  };

  return (
    <div className="flex-1 overflow-y-auto space-y-6 pr-1 h-full">
      <div>
        <h2 className="text-xl font-sans font-extrabold tracking-tight">System Subscription Plans</h2>
        <p className="text-xs text-zinc-500 font-medium">Configure your platform operational scale and upgrade tiers using Razorpay gateway.</p>
      </div>

      {/* Pricing cards grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {PLANS.map((plan) => (
          <div 
            key={plan.name}
            className={`p-6 rounded-2xl border flex flex-col justify-between relative transition hover:scale-[1.01] ${
              user.plan === plan.name 
                ? "border-indigo-600 ring-2 ring-indigo-600/20 bg-indigo-500/5"
                : theme === "dark" ? "bg-zinc-900 border-zinc-800" : "bg-white border-zinc-200 shadow-sm"
            }`}
          >
            {user.plan === plan.name && (
              <span className="absolute -top-3 left-6 px-3 py-1 bg-indigo-600 text-white rounded-full text-[9px] font-extrabold font-mono uppercase tracking-widest">
                Currently Active
              </span>
            )}

            <div className="space-y-4">
              <div>
                <span className="text-xs font-bold text-zinc-400 font-mono uppercase tracking-widest">{plan.name} Package</span>
                <div className="flex items-baseline gap-1.5 mt-1.5">
                  <h3 className="text-2xl font-extrabold tracking-tight font-sans text-zinc-900 dark:text-white">{plan.price}</h3>
                  <span className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider">/ Month</span>
                </div>
                <p className="text-[11px] text-zinc-500 mt-2.5 leading-relaxed">{plan.description}</p>
              </div>

              {/* feature list */}
              <div className="border-t border-zinc-200 dark:border-zinc-800 pt-4 space-y-2.5 text-xs text-zinc-500">
                {plan.features.map((feat, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                    <span>{feat}</span>
                  </div>
                ))}
              </div>
            </div>

            <button
              onClick={() => triggerCheckout(plan.name as any, plan.numericPrice)}
              disabled={user.plan === plan.name}
              className={`w-full mt-6 py-2 rounded-xl text-center text-xs font-bold transition flex items-center justify-center gap-1 shadow-sm ${
                user.plan === plan.name
                  ? "bg-zinc-500/10 border border-zinc-500/10 text-zinc-400 cursor-default"
                  : "bg-indigo-600 hover:bg-indigo-700 text-white shadow-indigo-600/10"
              }`}
              id={`btn-upgrade-${plan.name}`}
            >
              <span>{user.plan === plan.name ? "Current Node Tier" : "Upgrade via Razorpay"}</span>
            </button>
          </div>
        ))}
      </div>

      {/* RAZORPAY GATEWAY SIMULATOR MODAL */}
      {showRazorpay && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="w-[360px] rounded-2xl overflow-hidden bg-[#1a202c] text-white shadow-2xl border border-zinc-700/50">
            
            {/* checkout header */}
            <div className="bg-[#1e2530] p-4 flex items-center justify-between border-b border-zinc-700/50">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded bg-[#2e3748] flex items-center justify-center text-indigo-400 font-bold text-xs font-serif shadow-sm">
                  R
                </div>
                <div>
                  <h4 className="text-xs font-bold leading-none">Razorpay Checkout</h4>
                  <span className="text-[9px] text-zinc-400 mt-0.5 inline-block">AI Business OS Ltd.</span>
                </div>
              </div>
              <button 
                onClick={() => setShowRazorpay(false)} 
                className="p-1 rounded-lg text-zinc-400 hover:bg-zinc-700 transition"
                id="btn-close-razorpay"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Price section */}
            <div className="p-4 bg-[#212a38] flex justify-between items-center text-xs">
              <span className="text-zinc-400">Upgrading to {selectedPlan} Plan</span>
              <strong className="text-base text-indigo-400 font-mono">₹{priceToPay.toLocaleString("en-IN")}.00</strong>
            </div>

            {/* Checkout forms */}
            <form onSubmit={handleRazorpayPayment} className="p-4 space-y-4 text-xs">
              
              {/* Payment methods choice */}
              <div className="grid grid-cols-3 gap-1.5 border-b border-zinc-700/40 pb-3">
                <button type="button" className="p-2 rounded bg-indigo-500/10 border border-indigo-500/20 text-[10px] font-bold text-indigo-400 flex flex-col items-center gap-1">
                  <CreditCard className="w-4 h-4" />
                  <span>Cards</span>
                </button>
                <button type="button" className="p-2 rounded bg-zinc-800 text-[10px] text-zinc-400 flex flex-col items-center gap-1 opacity-50 cursor-default">
                  <Landmark className="w-4 h-4" />
                  <span>Netbanking</span>
                </button>
                <button type="button" className="p-2 rounded bg-zinc-800 text-[10px] text-zinc-400 flex flex-col items-center gap-1 opacity-50 cursor-default">
                  <Wallet className="w-4 h-4" />
                  <span>UPI / Wallet</span>
                </button>
              </div>

              {/* Card inputs */}
              <div className="space-y-3">
                <div>
                  <label className="block text-[8px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Card Number</label>
                  <input
                    type="text"
                    required
                    value={cardNo}
                    onChange={(e) => setCardNo(e.target.value)}
                    className="w-full bg-[#12161f] border border-zinc-700 rounded-lg p-2 font-mono text-center focus:outline-none focus:border-indigo-500 text-xs"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[8px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Expiry Date</label>
                    <input
                      type="text"
                      required
                      value={cardExpiry}
                      onChange={(e) => setCardExpiry(e.target.value)}
                      className="w-full bg-[#12161f] border border-zinc-700 rounded-lg p-2 font-mono text-center focus:outline-none focus:border-indigo-500 text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-[8px] font-bold text-zinc-400 uppercase tracking-widest mb-1">CVV Code</label>
                    <input
                      type="password"
                      required
                      value={cardCvv}
                      onChange={(e) => setCardCvv(e.target.value)}
                      className="w-full bg-[#12161f] border border-zinc-700 rounded-lg p-2 font-mono text-center focus:outline-none focus:border-indigo-500 text-xs"
                    />
                  </div>
                </div>
              </div>

              {/* Submit button */}
              <button
                type="submit"
                disabled={processing || success}
                className={`w-full py-2.5 rounded-xl text-center text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                  success 
                    ? "bg-emerald-500 text-white" 
                    : "bg-indigo-600 hover:bg-indigo-700 text-white shadow-lg shadow-indigo-600/10 disabled:opacity-50"
                }`}
                id="btn-razorpay-confirm"
              >
                {processing ? (
                  <>
                    <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Processing Securing...</span>
                  </>
                ) : success ? (
                  <>
                    <ShieldCheck className="w-4 h-4" />
                    <span>Razorpay Success!</span>
                  </>
                ) : (
                  <span>Simulate Payment of ₹{priceToPay}</span>
                )}
              </button>

              <div className="flex items-center gap-1 justify-center text-[8px] text-zinc-500 uppercase tracking-widest font-mono">
                <ShieldCheck className="w-3.5 h-3.5 text-indigo-500" />
                <span>SECURED BY RAZORPAY 256-BIT CRYPTO</span>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
