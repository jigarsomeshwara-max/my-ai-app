import React, { useState } from "react";
import { UserProfile } from "../types";
import { Mail, Lock, Shield, Building, KeyRound, AlertTriangle, ArrowRight } from "lucide-react";

interface AuthViewProps {
  onLoginSuccess: (user: UserProfile) => void;
  theme: "light" | "dark";
}

export default function AuthView({ onLoginSuccess, theme }: AuthViewProps) {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState("ceo@startup.co.in");
  const [password, setPassword] = useState("admin123");
  const [name, setName] = useState("Suresh Kumar");
  const [company, setCompany] = useState("Alpha Retail Technologies");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setError("Please fill in all standard credentials");
      return;
    }
    setError("");
    setLoading(true);

    setTimeout(() => {
      setLoading(false);
      const user: UserProfile = {
        id: "usr-" + Math.floor(Math.random() * 10000),
        email: email,
        name: isLogin ? (email === "ceo@startup.co.in" ? "Suresh Kumar" : email.split("@")[0]) : name,
        avatar: `https://api.dicebear.com/7.x/adventurer/svg?seed=${encodeURIComponent(email)}`,
        plan: "Free",
        companyName: isLogin ? (email === "ceo@startup.co.in" ? "Alpha Retail Technologies" : "Alpha Business Corp") : company
      };
      onLoginSuccess(user);
    }, 900);
  };

  const handleGoogleLogin = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      const user: UserProfile = {
        id: "usr-google",
        email: "jigarsomeshwara@gmail.com",
        name: "Jigar Someshwara",
        avatar: "https://api.dicebear.com/7.x/adventurer/svg?seed=jigar",
        plan: "Pro", // Starts with Pro subscription for premium experience!
        companyName: "Someshwara Consulting & AI Labs"
      };
      onLoginSuccess(user);
    }, 700);
  };

  return (
    <div className="flex-1 flex items-center justify-center py-10 px-4">
      <div className={`w-full max-w-md rounded-2xl border p-8 shadow-xl transition-all ${
        theme === "dark" 
          ? "bg-zinc-900 border-zinc-800 shadow-indigo-950/20" 
          : "bg-white border-zinc-200 shadow-zinc-200"
      }`}>
        <div className="text-center mb-6">
          <div className="w-12 h-12 rounded-2xl bg-indigo-600 flex items-center justify-center text-white font-bold text-xl mx-auto shadow-lg shadow-indigo-600/30 mb-3">
            Ω
          </div>
          <h2 className="text-2xl font-sans font-extrabold tracking-tight">
            {isLogin ? "Sign In to AI Business OS" : "Deploy Your Business OS"}
          </h2>
          <p className="text-xs text-zinc-500 mt-1">
            {isLogin ? "Empower your workflows with automated AI billing & CRM" : "Integrate all administrative nodes into one ledger"}
          </p>
        </div>

        {error && (
          <div className="mb-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-500 text-xs flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {!isLogin && (
            <>
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-500 mb-1.5">
                  Full Name
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 absolute left-3.5 top-3 text-zinc-400" />
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Suresh Kumar"
                    className={`w-full text-sm pl-10 pr-4 py-2.5 rounded-xl border focus:outline-none focus:ring-2 focus:ring-indigo-600 transition ${
                      theme === "dark" ? "bg-zinc-950 border-zinc-800 text-white" : "bg-zinc-50 border-zinc-200 text-zinc-900"
                    }`}
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-500 mb-1.5">
                  Company Legal Name
                </label>
                <div className="relative">
                  <Building className="w-4 h-4 absolute left-3.5 top-3 text-zinc-400" />
                  <input
                    type="text"
                    value={company}
                    onChange={(e) => setCompany(e.target.value)}
                    placeholder="Alpha Retail Technologies"
                    className={`w-full text-sm pl-10 pr-4 py-2.5 rounded-xl border focus:outline-none focus:ring-2 focus:ring-indigo-600 transition ${
                      theme === "dark" ? "bg-zinc-950 border-zinc-800 text-white" : "bg-zinc-50 border-zinc-200 text-zinc-900"
                    }`}
                    required
                  />
                </div>
              </div>
            </>
          )}

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-500 mb-1.5">
              Business Email Address
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 absolute left-3.5 top-3 text-zinc-400" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="ceo@startup.co.in"
                className={`w-full text-sm pl-10 pr-4 py-2.5 rounded-xl border focus:outline-none focus:ring-2 focus:ring-indigo-600 transition ${
                  theme === "dark" ? "bg-zinc-950 border-zinc-800 text-white" : "bg-zinc-50 border-zinc-200 text-zinc-900"
                }`}
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-500 mb-1.5">
              Secure Password
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 absolute left-3.5 top-3 text-zinc-400" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className={`w-full text-sm pl-10 pr-4 py-2.5 rounded-xl border focus:outline-none focus:ring-2 focus:ring-indigo-600 transition ${
                  theme === "dark" ? "bg-zinc-950 border-zinc-800 text-white" : "bg-zinc-50 border-zinc-200 text-zinc-900"
                }`}
                required
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold transition flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/20 disabled:opacity-50"
            id="btn-auth-submit"
          >
            {loading ? (
              <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <>
                <span>{isLogin ? "Authenticate Credentials" : "Initialize Master Ledger"}</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        <div className="relative flex py-4 items-center">
          <div className="flex-grow border-t border-zinc-300 dark:border-zinc-800"></div>
          <span className="flex-shrink mx-4 text-[10px] text-zinc-400 font-mono font-semibold uppercase tracking-widest">or SSO Integration</span>
          <div className="flex-grow border-t border-zinc-300 dark:border-zinc-800"></div>
        </div>

        <button
          onClick={handleGoogleLogin}
          disabled={loading}
          className={`w-full py-2.5 rounded-xl border text-sm font-semibold transition flex items-center justify-center gap-2 ${
            theme === "dark" 
              ? "bg-zinc-950 border-zinc-800 hover:bg-zinc-900 text-zinc-200" 
              : "bg-white border-zinc-200 hover:bg-zinc-50 text-zinc-700"
          }`}
          id="btn-google-auth"
        >
          <svg className="w-4 h-4 flex-shrink-0" viewBox="0 0 24 24">
            <path
              fill="#4285F4"
              d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
            />
            <path
              fill="#34A853"
              d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.56-2.77c-.98.66-2.23 1.06-3.72 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
            />
            <path
              fill="#FBBC05"
              d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
            />
            <path
              fill="#EA4335"
              d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
            />
          </svg>
          <span>Continue with Google Workspace</span>
        </button>

        <div className="text-center mt-6">
          <button
            onClick={() => setIsLogin(!isLogin)}
            className="text-xs text-indigo-500 hover:underline font-semibold"
            id="btn-toggle-auth-mode"
          >
            {isLogin ? "No operational profile? Create an Organization" : "Already registered? Login to Secure Node"}
          </button>
        </div>

        {isLogin && (
          <div className={`mt-5 p-3 rounded-xl border text-[11px] font-mono leading-relaxed transition ${
            theme === "dark" ? "bg-zinc-950/40 border-zinc-800 text-zinc-500" : "bg-zinc-50 border-zinc-150 text-zinc-500"
          }`}>
            <div className="flex gap-1 items-center font-bold text-indigo-500 mb-0.5 uppercase tracking-wider">
              <Shield className="w-3.5 h-3.5" />
              <span>Sandbox Quick Access Credentials:</span>
            </div>
            Email: <strong className="text-zinc-600 dark:text-zinc-400">ceo@startup.co.in</strong><br />
            Password: <strong className="text-zinc-600 dark:text-zinc-400">admin123</strong>
          </div>
        )}
      </div>
    </div>
  );
}
