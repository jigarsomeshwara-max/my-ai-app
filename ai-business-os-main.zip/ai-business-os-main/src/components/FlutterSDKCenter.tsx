import React, { useState } from "react";
import { 
  SUPABASE_SQL_SCHEMA, 
  FLUTTER_PUBSPEC, 
  FLUTTER_SUPABASE_SERVICE, 
  FLUTTER_GEMINI_SERVICE 
} from "../data";
import { Code, Database, Copy, Check, FileCode, CheckSquare, Layers, BookOpen } from "lucide-react";

interface FlutterSDKCenterProps {
  theme: "light" | "dark";
}

export default function FlutterSDKCenter({ theme }: FlutterSDKCenterProps) {
  const [activeTab, setActiveTab] = useState<"sql" | "pubspec" | "supabase-dart" | "gemini-dart" | "guides">("sql");
  const [copied, setCopied] = useState(false);

  const getCodeString = () => {
    switch (activeTab) {
      case "sql":
        return SUPABASE_SQL_SCHEMA;
      case "pubspec":
        return FLUTTER_PUBSPEC;
      case "supabase-dart":
        return FLUTTER_SUPABASE_SERVICE;
      case "gemini-dart":
        return FLUTTER_GEMINI_SERVICE;
      default:
        return "";
    }
  };

  const handleCopyCode = () => {
    const code = getCodeString();
    if (!code) return;
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex-1 overflow-y-auto space-y-6 pr-1 h-full">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-sans font-extrabold tracking-tight">Developer SDK & Export Center</h2>
          <p className="text-xs text-zinc-500 font-medium">Claim your compiled database architectures, mobile Flutter models, and app store bundling briefs.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        
        {/* Left Side: Tabs navigation lists */}
        <div className="lg:col-span-1 space-y-2">
          <span className="text-[9px] font-bold text-zinc-400 uppercase tracking-widest font-mono block mb-2 px-1">Compiled Deliverables</span>
          
          <button
            onClick={() => setActiveTab("sql")}
            className={`w-full flex items-center gap-2.5 p-3 rounded-xl border text-xs font-bold transition text-left ${
              activeTab === "sql"
                ? "bg-indigo-600 border-indigo-600 text-white shadow-md shadow-indigo-600/10"
                : theme === "dark" 
                  ? "bg-zinc-900 border-zinc-800 text-zinc-300 hover:bg-zinc-800" 
                  : "bg-white border-zinc-200 text-zinc-600 hover:bg-zinc-50"
            }`}
            id="btn-sdk-sql"
          >
            <Database className="w-4 h-4 flex-shrink-0" />
            <span>Supabase SQL Schema</span>
          </button>

          <button
            onClick={() => setActiveTab("pubspec")}
            className={`w-full flex items-center gap-2.5 p-3 rounded-xl border text-xs font-bold transition text-left ${
              activeTab === "pubspec"
                ? "bg-indigo-600 border-indigo-600 text-white shadow-md shadow-indigo-600/10"
                : theme === "dark" 
                  ? "bg-zinc-900 border-zinc-800 text-zinc-300 hover:bg-zinc-800" 
                  : "bg-white border-zinc-200 text-zinc-600 hover:bg-zinc-50"
            }`}
            id="btn-sdk-pubspec"
          >
            <FileCode className="w-4 h-4 flex-shrink-0" />
            <span>Flutter pubspec.yaml</span>
          </button>

          <button
            onClick={() => setActiveTab("supabase-dart")}
            className={`w-full flex items-center gap-2.5 p-3 rounded-xl border text-xs font-bold transition text-left ${
              activeTab === "supabase-dart"
                ? "bg-indigo-600 border-indigo-600 text-white shadow-md shadow-indigo-600/10"
                : theme === "dark" 
                  ? "bg-zinc-900 border-zinc-800 text-zinc-300 hover:bg-zinc-800" 
                  : "bg-white border-zinc-200 text-zinc-600 hover:bg-zinc-50"
            }`}
            id="btn-sdk-supabase-dart"
          >
            <Code className="w-4 h-4 flex-shrink-0" />
            <span>Dart Supabase Auth</span>
          </button>

          <button
            onClick={() => setActiveTab("gemini-dart")}
            className={`w-full flex items-center gap-2.5 p-3 rounded-xl border text-xs font-bold transition text-left ${
              activeTab === "gemini-dart"
                ? "bg-indigo-600 border-indigo-600 text-white shadow-md shadow-indigo-600/10"
                : theme === "dark" 
                  ? "bg-zinc-900 border-zinc-800 text-zinc-300 hover:bg-zinc-800" 
                  : "bg-white border-zinc-200 text-zinc-600 hover:bg-zinc-50"
            }`}
            id="btn-sdk-gemini-dart"
          >
            <Code className="w-4 h-4 flex-shrink-0" />
            <span>Dart Gemini Client</span>
          </button>

          <button
            onClick={() => setActiveTab("guides")}
            className={`w-full flex items-center gap-2.5 p-3 rounded-xl border text-xs font-bold transition text-left ${
              activeTab === "guides"
                ? "bg-indigo-600 border-indigo-600 text-white shadow-md shadow-indigo-600/10"
                : theme === "dark" 
                  ? "bg-zinc-900 border-zinc-800 text-zinc-300 hover:bg-zinc-800" 
                  : "bg-white border-zinc-200 text-zinc-600 hover:bg-zinc-50"
            }`}
            id="btn-sdk-guides"
          >
            <BookOpen className="w-4 h-4 flex-shrink-0" />
            <span>Play Store Release Plan</span>
          </button>
        </div>

        {/* Right Side: Tab content display pane */}
        <div className="lg:col-span-3 space-y-4">
          
          {activeTab !== "guides" ? (
            <div className={`p-5 rounded-2xl border flex flex-col justify-between ${
              theme === "dark" ? "bg-zinc-900 border-zinc-800" : "bg-white border-zinc-200 shadow-sm"
            }`}>
              <div className="space-y-4">
                <div className="flex items-center justify-between border-b pb-2">
                  <div className="flex items-center gap-1.5">
                    <Code className="w-4 h-4 text-indigo-500" />
                    <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest font-mono">
                      {activeTab === "sql" ? "Supabase schema.sql" : activeTab === "pubspec" ? "pubspec.yaml" : activeTab === "supabase-dart" ? "supabase_service.dart" : "gemini_service.dart"}
                    </span>
                  </div>

                  <button
                    onClick={handleCopyCode}
                    className="p-1.5 rounded-lg border border-zinc-200 dark:border-zinc-800 hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-500 transition inline-flex items-center gap-1 text-[11px] font-bold"
                    id="btn-copy-sdk"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? "Copied!" : "Copy Code"}</span>
                  </button>
                </div>

                <div className="p-4 rounded-xl bg-zinc-950 text-zinc-300 font-mono text-[10.5px] leading-relaxed max-h-[360px] overflow-y-auto whitespace-pre">
                  {getCodeString()}
                </div>
              </div>
            </div>
          ) : (
            <div className={`p-5 rounded-2xl border space-y-4 ${
              theme === "dark" ? "bg-zinc-900 border-zinc-800" : "bg-white border-zinc-200 shadow-sm"
            }`}>
              <div className="flex items-center gap-1.5 border-b pb-2">
                <CheckSquare className="w-4 h-4 text-indigo-500" />
                <h3 className="font-sans font-extrabold text-sm tracking-tight">Android Play Store Release Checklist</h3>
              </div>

              <div className="space-y-4 text-xs leading-relaxed text-zinc-600 dark:text-zinc-300">
                <div className="space-y-1">
                  <h4 className="font-bold text-zinc-900 dark:text-zinc-100">1. Android Build Setup (`/android/app/build.gradle`)</h4>
                  <p className="text-[11px] text-zinc-500">
                    - Setup your unique Application ID: `applicationId "com.aibusinessos.app"`<br />
                    - Configure signing keys inside `signingConfigs` utilizing key.properties credentials.<br />
                    - Set standard SDK parameters: `compileSdkVersion 34`, `minSdkVersion 21`.
                  </p>
                </div>

                <div className="space-y-1">
                  <h4 className="font-bold text-zinc-900 dark:text-zinc-100">2. Razorpay Key and Activity setups</h4>
                  <p className="text-[11px] text-zinc-500">
                    - In `AndroidManifest.xml`, configure the Razorpay payload event listener receiver node inside your main activity block.<br />
                    - Maintain environment secret mappings using --dart-define parameters inside your Flutter build terminal.
                  </p>
                </div>

                <div className="space-y-1">
                  <h4 className="font-bold text-zinc-900 dark:text-zinc-100">3. Firebase FCM Notification Hooks</h4>
                  <p className="text-[11px] text-zinc-500">
                    - Generate and download `google-services.json` from the Firebase Console dashboard.<br />
                    - Put the file at path: `/android/app/google-services.json`. Override standard Android push templates.<br />
                    - Enable the google-services plugin inside your app gradle dependencies.
                  </p>
                </div>

                <div className="space-y-1">
                  <h4 className="font-bold text-zinc-900 dark:text-zinc-100">4. Compile Production AAB Bundle</h4>
                  <p className="text-[11px] font-mono p-2 bg-zinc-950 text-indigo-400 rounded-lg">
                    flutter build appbundle --release --obfuscate --split-debug-info=build/app/outputs/symbols
                  </p>
                </div>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}
