import React, { useState } from "react";
import { Expense } from "../types";
import { Plus, Trash, Check, Receipt, Tag, DollarSign, Wand2, ShieldAlert, AlertCircle } from "lucide-react";

interface ExpenseTrackerViewProps {
  expenses: Expense[];
  onAddExpense: (expense: Expense) => void;
  theme: "light" | "dark";
}

export default function ExpenseTrackerView({ expenses, onAddExpense, theme }: ExpenseTrackerViewProps) {
  // Expense forms states
  const [amount, setAmount] = useState("");
  const [category, setCategory] = useState("Software Subscription");
  const [vendor, setVendor] = useState("");
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [description, setDescription] = useState("");
  const [tags, setTags] = useState("");

  // AI OCR Prompt simulator
  const [ocrInput, setOcrInput] = useState("");
  const [scanning, setScanning] = useState(false);
  const [scannerResult, setScannerResult] = useState<any>(null);

  const handleSubmitExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || !vendor || !category) return;

    const amt = parseFloat(amount);
    const gstRate = 18; // standard service tax
    const gstAmount = amt - (amt / (1 + gstRate / 100));

    const newExpense: Expense = {
      id: "exp-" + Date.now(),
      amount: amt,
      category,
      vendor,
      date,
      gstRate,
      gstAmount: parseFloat(gstAmount.toFixed(2)),
      description,
      tags: tags.split(",").map(t => t.trim()).filter(t => t.length > 0)
    };

    onAddExpense(newExpense);

    // reset
    setAmount("");
    setVendor("");
    setDescription("");
    setTags("");
  };

  const handleAIScan = async () => {
    if (!ocrInput.trim() || scanning) return;
    setScanning(true);
    setScannerResult(null);

    try {
      const response = await fetch("/api/ai/expense-scanner", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: ocrInput })
      });

      const result = await response.json();
      setScanning(false);

      if (result.success && result.data) {
        setScannerResult(result.data);
        // Autofill form
        setAmount(result.data.amount?.toString() || "");
        setCategory(result.data.category || "Software Subscription");
        setVendor(result.data.vendor || "");
        setTags(result.data.tags?.join(", ") || "");
        setDescription(`AI Extracted: ${ocrInput.slice(0, 50)}...`);
      }
    } catch (err) {
      setScanning(false);
      console.error(err);
    }
  };

  const totalOverage = expenses.reduce((sum, exp) => sum + exp.amount, 0);

  return (
    <div className="flex-1 overflow-y-auto space-y-6 pr-1 h-full">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-sans font-extrabold tracking-tight">Expense Tracker & Auditor</h2>
          <p className="text-xs text-zinc-500 font-medium">Log expenditures and extract receipts dynamically using AI parsing schemas.</p>
        </div>
        <div className="text-right">
          <span className="text-[10px] text-zinc-400 font-bold uppercase tracking-widest block font-mono">Ledger Overhead</span>
          <span className="text-sm font-bold font-mono text-rose-500">₹{totalOverage.toLocaleString("en-IN")}</span>
        </div>
      </div>

      {/* Main double column grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left column: Manual and AI receipt entries */}
        <div className="space-y-6 lg:col-span-1">
          {/* AI receipt parser */}
          <div className={`p-4 rounded-2xl border space-y-3 ${
            theme === "dark" ? "bg-zinc-900 border-zinc-800" : "bg-white border-zinc-200 shadow-sm"
          }`}>
            <div className="flex items-center justify-between">
              <h3 className="font-sans font-bold text-xs uppercase tracking-wider text-zinc-400 flex items-center gap-1">
                <Wand2 className="w-3.5 h-3.5 text-indigo-500 animate-pulse" />
                <span>AI OCR receipt scanner</span>
              </h3>
              <span className="text-[8px] font-bold font-mono text-indigo-500 bg-indigo-500/10 px-1.5 py-0.5 rounded">BETA</span>
            </div>
            
            <p className="text-[10px] text-zinc-500 leading-normal">
              Type or paste receipt text details (Vendor, products, pricing, and tax lines) and let Gemini structure the entry automatically.
            </p>

            <textarea
              value={ocrInput}
              onChange={(e) => setOcrInput(e.target.value)}
              placeholder="e.g., Croma retail invoice on 2026-07-02 for dynamic adaptors, price is 8200 rupees with standard tax rate."
              className={`w-full h-20 text-xs p-2.5 rounded-xl border focus:ring-1 focus:ring-indigo-500 focus:outline-none leading-relaxed ${
                theme === "dark" ? "bg-zinc-950 border-zinc-800 text-white" : "bg-zinc-50 border-zinc-200 text-zinc-900"
              }`}
            />

            <button
              type="button"
              onClick={handleAIScan}
              disabled={!ocrInput.trim() || scanning}
              className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition flex items-center justify-center gap-1 disabled:opacity-40"
              id="btn-ocr-scan"
            >
              {scanning ? (
                <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <Wand2 className="w-3.5 h-3.5" />
                  <span>Parse Receipt with Gemini</span>
                </>
              )}
            </button>

            {scannerResult && (
              <div className="p-2.5 rounded-xl bg-indigo-500/5 border border-indigo-500/10 text-[10px] font-mono leading-relaxed space-y-1 text-zinc-400">
                <div className="flex justify-between border-b pb-0.5 font-bold uppercase tracking-wider text-indigo-500">
                  <span>AI Extracted Properties</span>
                  <span>{Math.round(scannerResult.confidence * 100)}% Match</span>
                </div>
                <div className="flex justify-between">
                  <span>Vendor:</span>
                  <strong className="text-zinc-600 dark:text-zinc-300">{scannerResult.vendor}</strong>
                </div>
                <div className="flex justify-between">
                  <span>Base Amount:</span>
                  <strong className="text-zinc-600 dark:text-zinc-300">₹{scannerResult.amount}</strong>
                </div>
                <div className="flex justify-between">
                  <span>Category:</span>
                  <strong className="text-zinc-600 dark:text-zinc-300">{scannerResult.category}</strong>
                </div>
              </div>
            )}
          </div>

          {/* Manual Entry Form */}
          <div className={`p-5 rounded-2xl border ${
            theme === "dark" ? "bg-zinc-900 border-zinc-800" : "bg-white border-zinc-200 shadow-sm"
          }`}>
            <h3 className="font-sans font-extrabold text-sm border-b pb-2 tracking-tight mb-4">Log Manual Expense</h3>

            <form onSubmit={handleSubmitExpense} className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                  Vendor Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="AWS, Google Ads, Croma"
                  value={vendor}
                  onChange={(e) => setVendor(e.target.value)}
                  className={`w-full text-xs px-3 py-2 rounded-xl border focus:ring-1 focus:ring-indigo-600 focus:outline-none ${
                    theme === "dark" ? "bg-zinc-950 border-zinc-800 text-white" : "bg-zinc-50 border-zinc-200 text-zinc-900"
                  }`}
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                    Amount (₹)
                  </label>
                  <input
                    type="number"
                    required
                    placeholder="2500"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className={`w-full text-xs px-3 py-2 rounded-xl border focus:ring-1 focus:ring-indigo-600 focus:outline-none ${
                      theme === "dark" ? "bg-zinc-950 border-zinc-800 text-white" : "bg-zinc-50 border-zinc-200 text-zinc-900"
                    }`}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                    Transaction Date
                  </label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className={`w-full text-xs px-2 py-2 rounded-xl border focus:ring-1 focus:ring-indigo-600 focus:outline-none ${
                      theme === "dark" ? "bg-zinc-950 border-zinc-800 text-white" : "bg-zinc-50 border-zinc-200 text-zinc-900"
                    }`}
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                  Tax Category
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className={`w-full text-xs px-3 py-2 rounded-xl border focus:outline-none ${
                    theme === "dark" ? "bg-zinc-950 border-zinc-800 text-white" : "bg-zinc-50 border-zinc-200 text-zinc-900"
                  }`}
                >
                  <option value="Software Subscription">Software / SaaS Subscription</option>
                  <option value="Marketing">Marketing & Lead Ads</option>
                  <option value="Office Supplies">Office Operational Supplies</option>
                  <option value="Logistics">Logistics & Warehousing</option>
                  <option value="Travel">Business Travel & Hosting</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                  Tags (Comma separated)
                </label>
                <input
                  type="text"
                  placeholder="cloud, design, equipment"
                  value={tags}
                  onChange={(e) => setTags(e.target.value)}
                  className={`w-full text-xs px-3 py-2 rounded-xl border focus:ring-1 focus:ring-indigo-600 focus:outline-none ${
                    theme === "dark" ? "bg-zinc-950 border-zinc-800 text-white" : "bg-zinc-50 border-zinc-200 text-zinc-900"
                  }`}
                />
              </div>

              <button
                type="submit"
                className="w-full py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition flex items-center justify-center gap-1 shadow"
                id="btn-expense-submit"
              >
                <Check className="w-4 h-4" />
                <span>Log Overhead Expense</span>
              </button>
            </form>
          </div>
        </div>

        {/* Right column: Ledger Entries List */}
        <div className={`lg:col-span-2 border rounded-2xl overflow-hidden ${
          theme === "dark" ? "bg-zinc-900 border-zinc-800" : "bg-white border-zinc-200 shadow-sm"
        }`}>
          <div className="p-4 border-b border-zinc-200 dark:border-zinc-800 flex items-center gap-2">
            <Receipt className="w-4.5 h-4.5 text-indigo-500" />
            <h3 className="font-sans font-bold text-xs uppercase tracking-wider text-zinc-400">Expense Ledger Journal</h3>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className={`border-b ${
                theme === "dark" ? "bg-zinc-950/40 border-zinc-800 text-zinc-400" : "bg-zinc-50 border-zinc-200 text-zinc-500"
              }`}>
                <tr>
                  <th className="p-4 font-semibold">Vendor / Category</th>
                  <th className="p-4 font-semibold">Transaction Date</th>
                  <th className="p-4 font-semibold">Computed Input GST</th>
                  <th className="p-4 font-semibold">Amount Total</th>
                  <th className="p-4 font-semibold text-right">Audit Tags</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-200 dark:divide-zinc-800">
                {expenses.map((exp) => (
                  <tr key={exp.id} className="hover:bg-zinc-500/5 transition">
                    <td className="p-4">
                      <div>
                        <span className="font-bold block text-zinc-900 dark:text-zinc-100">{exp.vendor}</span>
                        <span className="text-[10px] text-zinc-500">{exp.category}</span>
                      </div>
                    </td>
                    <td className="p-4 font-mono">{exp.date}</td>
                    <td className="p-4 font-mono text-zinc-500">₹{exp.gstAmount} (18% Input)</td>
                    <td className="p-4 font-bold font-mono text-rose-500">₹{exp.amount.toLocaleString("en-IN")}</td>
                    <td className="p-4 text-right">
                      <div className="flex gap-1 justify-end flex-wrap">
                        {exp.tags.map((tag, i) => (
                          <span key={i} className="px-2 py-0.5 rounded bg-zinc-500/10 border border-zinc-500/20 text-[9px] font-mono font-medium text-zinc-400">
                            {tag}
                          </span>
                        ))}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
