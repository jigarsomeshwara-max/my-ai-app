import React from "react";
import { Monitor, Smartphone, Tablet, Sun, Moon, Wifi, Battery, Signal } from "lucide-react";

interface DeviceShellProps {
  activeDevice: "web" | "iphone" | "android";
  onChangeDevice: (device: "web" | "iphone" | "android") => void;
  theme: "light" | "dark";
  onToggleTheme: () => void;
  children: React.ReactNode;
}

export default function DeviceShell({
  activeDevice,
  onChangeDevice,
  theme,
  onToggleTheme,
  children,
}: DeviceShellProps) {
  const timeStr = "09:41";

  return (
    <div className={`w-full h-full flex-1 flex flex-col min-h-0 transition-colors duration-300 ${
      theme === "dark" ? "bg-zinc-950 text-zinc-100" : "bg-zinc-50 text-zinc-900"
    }`}>
      {/* Platform Controller Header */}
      <header className={`border-b px-3 py-2.5 sm:px-6 sm:py-3 flex items-center justify-between shadow-sm sticky top-0 z-40 transition-colors duration-200 ${
        theme === "dark" ? "bg-zinc-900/90 border-zinc-800 backdrop-blur" : "bg-white/90 border-zinc-200 backdrop-blur"
      }`}>
        <div className="flex items-center gap-1.5 sm:gap-2.5">
          <div className="hidden min-[450px]:flex w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-indigo-600 items-center justify-center text-white font-bold text-xs sm:text-sm shadow-md shadow-indigo-600/30">
            Ω
          </div>
          <div>
            <h1 className="font-sans font-bold text-xs sm:text-sm md:text-base tracking-tight leading-none">
              AI Business OS
            </h1>
            <span className="hidden min-[450px]:block text-[8px] sm:text-[10px] font-mono text-indigo-500 font-semibold uppercase tracking-wider mt-0.5">
              Omni-Channel Suite v1.0
            </span>
          </div>
        </div>

        {/* Device Switcher Controls */}
        <div className={`flex items-center gap-1.5 p-1 rounded-xl border ${
          theme === "dark" ? "bg-zinc-950/50 border-zinc-800" : "bg-zinc-100 border-zinc-200"
        }`}>
          <button
            onClick={() => onChangeDevice("web")}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeDevice === "web"
                ? "bg-indigo-600 text-white shadow"
                : "text-zinc-500 hover:text-indigo-500"
            }`}
            title="Desktop Web Interface"
            id="btn-shell-web"
          >
            <Monitor className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Web Workspace</span>
          </button>
          <button
            onClick={() => onChangeDevice("iphone")}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeDevice === "iphone"
                ? "bg-indigo-600 text-white shadow"
                : "text-zinc-500 hover:text-indigo-500"
            }`}
            title="Simulated iPhone 15 Pro"
            id="btn-shell-iphone"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span className="hidden md:inline">iPhone iOS</span>
          </button>
          <button
            onClick={() => onChangeDevice("android")}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeDevice === "android"
                ? "bg-indigo-600 text-white shadow"
                : "text-zinc-500 hover:text-indigo-500"
            }`}
            title="Simulated Android Galaxy"
            id="btn-shell-android"
          >
            <Tablet className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Android M3</span>
          </button>
        </div>

        {/* Theme and Status Controls */}
        <div className="flex items-center gap-3">
          <button
            onClick={onToggleTheme}
            className={`p-2 rounded-xl transition-colors border hover:bg-zinc-100 dark:hover:bg-zinc-800 ${
              theme === "dark" ? "border-zinc-800 text-amber-400" : "border-zinc-200 text-zinc-600"
            }`}
            id="btn-theme-toggle"
            title="Toggle Visual Theme"
          >
            {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
          
          <div className="hidden sm:flex items-center gap-2 px-3 py-1 rounded-full text-[11px] font-mono border border-indigo-500/20 bg-indigo-500/5 text-indigo-500 font-semibold">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
            SUPABASE SYNCHRONIZED
          </div>
        </div>
      </header>

      {/* Main Container - Renders Web full-bleed or centered Mobile Shell frame */}
      <main className="flex-1 flex items-center justify-center overflow-auto p-1 sm:p-4 md:p-6 lg:p-8">
        {activeDevice === "web" ? (
          <div className="w-full h-full max-w-7xl mx-auto flex flex-col flex-1 animate-fade-in" id="web-stage-root">
            {children}
          </div>
        ) : (
          <div className="relative flex flex-col items-center py-2 sm:py-4 max-w-full">
            {/* Phone Container Frame */}
            <div className={`relative transition-all duration-300 shadow-2xl rounded-[32px] sm:rounded-[50px] border-4 sm:border-[12px] overflow-hidden flex flex-col max-w-full ${
              activeDevice === "iphone" 
                ? "w-full max-w-[350px] h-[640px] sm:w-[380px] sm:h-[780px] sm:rounded-[55px] border-zinc-900 bg-zinc-950 shadow-black/40 ring-1 ring-zinc-800" 
                : "w-full max-w-[350px] h-[620px] sm:w-[390px] sm:h-[760px] sm:rounded-[36px] border-zinc-800 bg-zinc-950 shadow-black/40"
            }`} id="mobile-device-frame">
              
              {/* iOS Dynamic Island or Android Camera Hole */}
              {activeDevice === "iphone" ? (
                <div className="absolute top-3 left-1/2 -translate-x-1/2 w-28 h-7 bg-black rounded-full z-50 flex items-center justify-between px-3.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-500/70" />
                  <span className="w-2.5 h-1 bg-zinc-900 rounded-full" />
                </div>
              ) : (
                <div className="absolute top-3.5 left-1/2 -translate-x-1/2 w-3.5 h-3.5 bg-zinc-900 rounded-full z-50 border border-zinc-800" />
              )}

              {/* simulated device status bar */}
              <div className={`h-11 px-6 flex items-end justify-between text-xs font-semibold select-none z-40 transition-colors ${
                theme === "dark" ? "bg-zinc-900 text-zinc-100" : "bg-zinc-100 text-zinc-800"
              }`}>
                <span className="text-[11px] font-medium font-sans leading-none pb-1">{timeStr}</span>
                <div className="flex items-center gap-1.5 pb-1">
                  <Signal className="w-3.5 h-3.5 stroke-[2.5]" />
                  <Wifi className="w-3.5 h-3.5" />
                  <Battery className="w-4 h-4 text-emerald-500" />
                </div>
              </div>

              {/* Nested Application Space */}
              <div className="flex-1 overflow-y-auto overflow-x-hidden flex flex-col relative bg-zinc-50 dark:bg-zinc-950">
                {children}
              </div>

              {/* Home Navigation bar overlay */}
              <div className={`h-5 flex items-center justify-center select-none z-40 transition-colors ${
                theme === "dark" ? "bg-zinc-900" : "bg-zinc-100"
              }`}>
                {activeDevice === "iphone" ? (
                  <div className="w-32 h-1 bg-zinc-400 dark:bg-zinc-700 rounded-full mb-1" />
                ) : (
                  <div className="flex items-center justify-center gap-10 text-zinc-400 dark:text-zinc-600 text-[10px] tracking-widest font-bold">
                    <span>◀</span>
                    <span>●</span>
                    <span>■</span>
                  </div>
                )}
              </div>
            </div>
            
            <div className="mt-2 text-center">
              <span className="text-[11px] font-mono font-medium text-zinc-500 dark:text-zinc-400">
                Simulated {activeDevice === "iphone" ? "Apple iPhone 15 Pro" : "Google Material 3 Canvas"}
              </span>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
