import React, { useState } from "react";
import { Invoice, InvoiceItem } from "../types";
import { Plus, Trash, Check, Receipt, Printer, FileText, Download, Eye, ArrowLeft, Building2 } from "lucide-react";

interface InvoiceViewProps {
  invoices: Invoice[];
  onAddInvoice: (invoice: Invoice) => void;
  theme: "light" | "dark";
}

export default function InvoiceView({ invoices, onAddInvoice, theme }: InvoiceViewProps) {
  const [viewMode, setViewMode] = useState<"list" | "create" | "detail">("list");
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);

  // Form State
  const [clientName, setClientName] = useState("");
  const [clientEmail, setClientEmail] = useState("");
  const [clientGstin, setClientGstin] = useState("");
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [dueDate, setDueDate] = useState(
    new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0]
  );
  const [gstRate, setGstRate] = useState(18);
  const [discount, setDiscount] = useState(0);
  const [items, setItems] = useState<InvoiceItem[]>([
    { id: "item-1", description: "Strategic Tech Advisory License", quantity: 1, rate: 45000 },
  ]);

  // Temporary row state
  const [newItemDesc, setNewItemDesc] = useState("");
  const [newItemQty, setNewItemQty] = useState(1);
  const [newItemRate, setNewItemRate] = useState(0);

  const handleAddItem = () => {
    if (!newItemDesc) return;
    const newItem: InvoiceItem = {
      id: "item-" + Date.now(),
      description: newItemDesc,
      quantity: newItemQty,
      rate: newItemRate,
    };
    setItems([...items, newItem]);
    setNewItemDesc("");
    setNewItemQty(1);
    setNewItemRate(0);
  };

  const handleRemoveItem = (id: string) => {
    setItems(items.filter((item) => item.id !== id));
  };

  // Computations
  const subTotal = items.reduce((sum, item) => sum + item.quantity * item.rate, 0);
  const discountAmount = discount;
  const netTaxable = Math.max(0, subTotal - discountAmount);
  const gstAmount = netTaxable * (gstRate / 100);
  const grandTotal = Math.round(netTaxable + gstAmount);

  const handleSaveInvoice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!clientName || !clientEmail || items.length === 0) return;

    const newInvoice: Invoice = {
      id: "inv-" + Date.now(),
      invoiceNumber: "INV-2026-00" + (invoices.length + 1),
      clientName,
      clientEmail,
      clientGstin: clientGstin || undefined,
      date,
      dueDate,
      items,
      gstRate,
      discount,
      status: "Unpaid",
      total: grandTotal,
    };

    onAddInvoice(newInvoice);
    setSelectedInvoice(newInvoice);
    setViewMode("detail");

    // reset
    setClientName("");
    setClientEmail("");
    setClientGstin("");
    setItems([{ id: "item-init", description: "Consulting Operations Fee", quantity: 1, rate: 35000 }]);
    setDiscount(0);
  };

  const triggerPrint = () => {
    window.print();
  };

  return (
    <div className="flex-1 overflow-y-auto space-y-6 pr-1 h-full">
      {/* View Controller Headers */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-sans font-extrabold tracking-tight">Invoice Generator</h2>
          <p className="text-xs text-zinc-500">Produce GST/IGST compliant business invoices & generate PDF receipts.</p>
        </div>

        {viewMode === "list" ? (
          <button
            onClick={() => setViewMode("create")}
            className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 shadow"
            id="btn-invoice-new"
          >
            <Plus className="w-4 h-4" />
            <span>Generate Custom Invoice</span>
          </button>
        ) : (
          <button
            onClick={() => setViewMode("list")}
            className="px-3 py-1.5 border border-zinc-200 dark:border-zinc-800 rounded-xl text-xs font-semibold flex items-center gap-1 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition"
            id="btn-invoice-back"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>View All Invoices</span>
          </button>
        )}
      </div>

      {/* 1. LEDGER LIST VIEW */}
      {viewMode === "list" && (
        <div className={`border rounded-2xl overflow-hidden ${
          theme === "dark" ? "bg-zinc-900 border-zinc-800" : "bg-white border-zinc-200 shadow-sm"
        }`}>
          <div className="p-4 border-b border-zinc-200 dark:border-zinc-800 flex items-center gap-2">
            <Receipt className="w-4.5 h-4.5 text-indigo-500" />
            <h3 className="font-sans font-bold text-xs uppercase tracking-wider text-zinc-400">Master Invoice Register</h3>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className={`border-b ${
                theme === "dark" ? "bg-zinc-950/40 border-zinc-800 text-zinc-400" : "bg-zinc-50 border-zinc-200 text-zinc-500"
              }`}>
                <tr>
                  <th className="p-4 font-semibold">Invoice ID</th>
                  <th className="p-4 font-semibold">Client Organization</th>
                  <th className="p-4 font-semibold">Created On</th>
                  <th className="p-4 font-semibold">Tax Base</th>
                  <th className="p-4 font-semibold">Amount Total</th>
                  <th className="p-4 font-semibold">Audit Status</th>
                  <th className="p-4 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-200 dark:divide-zinc-800">
                {invoices.map((inv) => (
                  <tr key={inv.id} className="hover:bg-zinc-500/5 transition">
                    <td className="p-4 font-mono font-bold text-indigo-500">{inv.invoiceNumber}</td>
                    <td className="p-4">
                      <div>
                        <span className="font-bold block">{inv.clientName}</span>
                        <span className="text-[10px] text-zinc-500">{inv.clientEmail}</span>
                      </div>
                    </td>
                    <td className="p-4 font-mono">{inv.date}</td>
                    <td className="p-4 font-mono">{inv.gstRate}% GST</td>
                    <td className="p-4 font-bold font-mono">₹{inv.total.toLocaleString("en-IN")}</td>
                    <td className="p-4">
                      <span className={`px-2 py-1 rounded-full text-[9px] font-mono font-bold border ${
                        inv.status === "Paid"
                          ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-500"
                          : "bg-amber-500/10 border-amber-500/20 text-amber-500"
                      }`}>
                        {inv.status}
                      </span>
                    </td>
                    <td className="p-4 text-right">
                      <button
                        onClick={() => {
                          setSelectedInvoice(inv);
                          setViewMode("detail");
                        }}
                        className="p-1.5 rounded-lg border border-zinc-200 dark:border-zinc-800 hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-500 transition inline-flex items-center gap-1"
                        id={`btn-view-invoice-${inv.id}`}
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span className="text-[10px] font-bold">View</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 2. CREATE INVOICE VIEW */}
      {viewMode === "create" && (
        <form onSubmit={handleSaveInvoice} className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* parameters entry panel */}
          <div className={`lg:col-span-2 p-5 rounded-2xl border space-y-4 ${
            theme === "dark" ? "bg-zinc-900 border-zinc-800" : "bg-white border-zinc-200 shadow-sm"
          }`}>
            <h3 className="font-sans font-extrabold text-sm border-b pb-2 tracking-tight">Invoice parameters</h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                  Client Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="Zenith Solutions Ltd"
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  className={`w-full text-xs px-3 py-2 rounded-xl border focus:ring-1 focus:ring-indigo-600 focus:outline-none ${
                    theme === "dark" ? "bg-zinc-950 border-zinc-800 text-white" : "bg-zinc-50 border-zinc-200 text-zinc-900"
                  }`}
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                  Client Email Address
                </label>
                <input
                  type="email"
                  required
                  placeholder="accounts@zenith.in"
                  value={clientEmail}
                  onChange={(e) => setClientEmail(e.target.value)}
                  className={`w-full text-xs px-3 py-2 rounded-xl border focus:ring-1 focus:ring-indigo-600 focus:outline-none ${
                    theme === "dark" ? "bg-zinc-950 border-zinc-800 text-white" : "bg-zinc-50 border-zinc-200 text-zinc-900"
                  }`}
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                  Client GSTIN (Optional)
                </label>
                <input
                  type="text"
                  placeholder="27AAAAA1111A1Z1"
                  value={clientGstin}
                  onChange={(e) => setClientGstin(e.target.value)}
                  className={`w-full text-xs px-3 py-2 rounded-xl border focus:ring-1 focus:ring-indigo-600 focus:outline-none ${
                    theme === "dark" ? "bg-zinc-950 border-zinc-800 text-white" : "bg-zinc-50 border-zinc-200 text-zinc-900"
                  }`}
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                    Issue Date
                  </label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className={`w-full text-xs px-2 py-2 rounded-xl border focus:ring-1 focus:ring-indigo-500 focus:outline-none ${
                      theme === "dark" ? "bg-zinc-950 border-zinc-800 text-white" : "bg-zinc-50 border-zinc-200 text-zinc-900"
                    }`}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                    Due Date
                  </label>
                  <input
                    type="date"
                    required
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className={`w-full text-xs px-2 py-2 rounded-xl border focus:ring-1 focus:ring-indigo-500 focus:outline-none ${
                      theme === "dark" ? "bg-zinc-950 border-zinc-800 text-white" : "bg-zinc-50 border-zinc-200 text-zinc-900"
                    }`}
                  />
                </div>
              </div>
            </div>

            {/* Line items list editor */}
            <div className="space-y-3 pt-3">
              <h4 className="text-xs font-bold uppercase tracking-widest text-zinc-400 font-mono">Invoice Ledger Lines</h4>
              <div className="border rounded-xl overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className={theme === "dark" ? "bg-zinc-950/50" : "bg-zinc-50"}>
                    <tr className="border-b border-zinc-200 dark:border-zinc-800">
                      <th className="p-2.5 font-semibold">Description</th>
                      <th className="p-2.5 font-semibold w-16 text-center">Qty</th>
                      <th className="p-2.5 font-semibold w-24 text-right">Rate</th>
                      <th className="p-2.5 font-semibold w-24 text-right">Subtotal</th>
                      <th className="p-2.5 w-10"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-200 dark:divide-zinc-800">
                    {items.map((item) => (
                      <tr key={item.id}>
                        <td className="p-2.5 text-zinc-600 dark:text-zinc-300 font-medium">{item.description}</td>
                        <td className="p-2.5 text-center font-mono">{item.quantity}</td>
                        <td className="p-2.5 text-right font-mono">₹{item.rate.toLocaleString("en-IN")}</td>
                        <td className="p-2.5 text-right font-mono">₹{(item.quantity * item.rate).toLocaleString("en-IN")}</td>
                        <td className="p-2.5 text-center">
                          <button
                            type="button"
                            onClick={() => handleRemoveItem(item.id)}
                            className="text-rose-500 hover:bg-rose-500/10 p-1 rounded"
                            title="Remove Line"
                          >
                            <Trash className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                    {/* add item interface */}
                    <tr className={theme === "dark" ? "bg-zinc-950/20" : "bg-zinc-50/40"}>
                      <td className="p-2">
                        <input
                          type="text"
                          placeholder="Line Description (e.g., Software Consulting Service)"
                          value={newItemDesc}
                          onChange={(e) => setNewItemDesc(e.target.value)}
                          className={`w-full text-xs p-1.5 rounded-lg border focus:outline-none ${
                            theme === "dark" ? "bg-zinc-950 border-zinc-800 text-white" : "bg-white border-zinc-200 text-zinc-900"
                          }`}
                        />
                      </td>
                      <td className="p-2">
                        <input
                          type="number"
                          min="1"
                          value={newItemQty}
                          onChange={(e) => setNewItemQty(Math.max(1, parseInt(e.target.value) || 1))}
                          className={`w-full text-xs p-1.5 rounded-lg border text-center focus:outline-none ${
                            theme === "dark" ? "bg-zinc-950 border-zinc-800 text-white" : "bg-white border-zinc-200 text-zinc-900"
                          }`}
                        />
                      </td>
                      <td className="p-2">
                        <input
                          type="number"
                          placeholder="Rate (₹)"
                          value={newItemRate || ""}
                          onChange={(e) => setNewItemRate(Math.max(0, parseFloat(e.target.value) || 0))}
                          className={`w-full text-xs p-1.5 rounded-lg border text-right focus:outline-none ${
                            theme === "dark" ? "bg-zinc-950 border-zinc-800 text-white" : "bg-white border-zinc-200 text-zinc-900"
                          }`}
                        />
                      </td>
                      <td className="p-2 text-right font-mono font-bold text-indigo-500">
                        ₹{(newItemQty * newItemRate).toLocaleString("en-IN")}
                      </td>
                      <td className="p-2 text-center">
                        <button
                          type="button"
                          onClick={handleAddItem}
                          disabled={!newItemDesc}
                          className="p-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg disabled:opacity-40"
                          title="Confirm Line Item"
                          id="btn-invoice-add-line"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Tax summary & billing panel */}
          <div className="space-y-6">
            <div className={`p-5 rounded-2xl border space-y-4 ${
              theme === "dark" ? "bg-zinc-900 border-zinc-800" : "bg-white border-zinc-200 shadow-sm"
            }`}>
              <h3 className="font-sans font-extrabold text-sm border-b pb-2 tracking-tight">Financial Auditing</h3>

              <div className="space-y-3">
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                    GST Regulatory Rate (%)
                  </label>
                  <select
                    value={gstRate}
                    onChange={(e) => setGstRate(parseInt(e.target.value))}
                    className={`w-full text-xs px-3 py-2 rounded-xl border focus:outline-none ${
                      theme === "dark" ? "bg-zinc-950 border-zinc-800 text-white" : "bg-zinc-50 border-zinc-200 text-zinc-900"
                    }`}
                  >
                    <option value="18">18% GST (Standard Services)</option>
                    <option value="12">12% GST (Contract Utilities)</option>
                    <option value="5">5% GST (Consumables)</option>
                    <option value="28">28% GST (Luxury assets)</option>
                    <option value="0">0% GST (Zero-rated / Export)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                    Discount Deduction (₹)
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={discount || ""}
                    onChange={(e) => setDiscount(Math.max(0, parseFloat(e.target.value) || 0))}
                    placeholder="e.g. 5000"
                    className={`w-full text-xs px-3 py-2 rounded-xl border focus:outline-none ${
                      theme === "dark" ? "bg-zinc-950 border-zinc-800 text-white" : "bg-zinc-50 border-zinc-200 text-zinc-900"
                    }`}
                  />
                </div>
              </div>

              {/* pricing breakdown table */}
              <div className="border-t border-zinc-200 dark:border-zinc-800 pt-3 space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-zinc-500">Subtotal base:</span>
                  <span className="font-mono">₹{subTotal.toLocaleString("en-IN")}</span>
                </div>
                {discountAmount > 0 && (
                  <div className="flex justify-between text-rose-500">
                    <span>Discount reduction:</span>
                    <span className="font-mono">-₹{discountAmount.toLocaleString("en-IN")}</span>
                  </div>
                )}
                <div className="flex justify-between text-zinc-500">
                  <span>Net Taxable Base:</span>
                  <span className="font-mono">₹{netTaxable.toLocaleString("en-IN")}</span>
                </div>
                <div className="flex justify-between text-zinc-500">
                  <span>Computed IGST ({gstRate}%):</span>
                  <span className="font-mono">₹{gstAmount.toLocaleString("en-IN")}</span>
                </div>
                <div className="flex justify-between border-t border-zinc-200 dark:border-zinc-800 pt-2 font-bold text-sm">
                  <span>Grand total (Round):</span>
                  <span className="font-mono text-indigo-500">₹{grandTotal.toLocaleString("en-IN")}</span>
                </div>
              </div>

              <button
                type="submit"
                disabled={items.length === 0}
                className="w-full mt-2 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition flex items-center justify-center gap-1.5 shadow shadow-indigo-600/10 disabled:opacity-50"
                id="btn-invoice-submit"
              >
                <Check className="w-4 h-4" />
                <span>Initialize Invoice Ledger</span>
              </button>
            </div>
          </div>
        </form>
      )}

      {/* 3. PRINTABLE DETAILED VIEW */}
      {viewMode === "detail" && selectedInvoice && (
        <div className="space-y-6 max-w-3xl mx-auto">
          {/* download/print bar controls */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl border border-indigo-500/20 bg-indigo-500/5 text-xs text-zinc-500">
            <div className="flex items-center gap-2">
              <FileText className="w-4.5 h-4.5 text-indigo-500" />
              <span>Invoice <strong className="text-zinc-700 dark:text-zinc-300">{selectedInvoice.invoiceNumber}</strong> finalized.</span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={triggerPrint}
                className="px-3 py-1.5 bg-zinc-900 hover:bg-zinc-800 text-white rounded-lg text-xs font-bold transition flex items-center gap-1 shadow"
                title="Print Invoice"
                id="btn-invoice-print"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print PDF</span>
              </button>
            </div>
          </div>

          {/* Actual Invoicing printable sheet card */}
          <div className="p-8 rounded-3xl border bg-white text-zinc-950 font-sans shadow-xl shadow-zinc-200/50 dark:shadow-none" id="printable-invoice-sheet">
            {/* invoice header block */}
            <div className="flex items-start justify-between border-b pb-6">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-7 h-7 rounded bg-indigo-600 flex items-center justify-center text-white font-bold text-sm">
                    Ω
                  </div>
                  <span className="font-extrabold text-base tracking-tight text-zinc-900">AI Business OS Ltd.</span>
                </div>
                <div className="text-[10px] text-zinc-500 leading-tight space-y-0.5">
                  <p>102, Innovation Towers, Bandra Kurla Complex</p>
                  <p>Mumbai, Maharashtra - 400051</p>
                  <p>Email: finance@aibusinessos.co | GSTIN: 27AABCA9087C1ZS</p>
                </div>
              </div>

              <div className="text-right">
                <h2 className="text-xl font-extrabold tracking-tight text-indigo-600 uppercase">INVOICE</h2>
                <div className="text-[10px] text-zinc-500 mt-2 space-y-0.5">
                  <p>Invoice #: <strong className="text-zinc-900">{selectedInvoice.invoiceNumber}</strong></p>
                  <p>Issue Date: <span className="font-mono text-zinc-900">{selectedInvoice.date}</span></p>
                  <p>Due Date: <span className="font-mono text-zinc-900">{selectedInvoice.dueDate}</span></p>
                </div>
              </div>
            </div>

            {/* billing entities information */}
            <div className="grid grid-cols-2 gap-6 py-6 text-xs">
              <div>
                <span className="block text-[9px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Billed To:</span>
                <h4 className="font-bold text-zinc-900 leading-none mb-1">{selectedInvoice.clientName}</h4>
                <p className="text-zinc-500">{selectedInvoice.clientEmail}</p>
                {selectedInvoice.clientGstin && (
                  <p className="text-[10px] font-mono text-zinc-500 mt-1">GSTIN: <strong className="text-zinc-800">{selectedInvoice.clientGstin}</strong></p>
                )}
              </div>

              <div className="text-right">
                <span className="block text-[9px] font-bold text-zinc-400 uppercase tracking-widest mb-1">State of Supply:</span>
                <p className="text-zinc-900 font-medium">Maharashtra (Inter-State Tax Regime)</p>
                <p className="text-zinc-500">Service Accounting Code (SAC): 998311</p>
              </div>
            </div>

            {/* line items register table */}
            <div className="border rounded-lg overflow-hidden my-4 text-xs">
              <table className="w-full text-left">
                <thead className="bg-zinc-50 text-zinc-500 border-b">
                  <tr>
                    <th className="p-3 font-semibold">Service Description / SAC</th>
                    <th className="p-3 font-semibold text-center w-12">Qty</th>
                    <th className="p-3 font-semibold text-right w-24">Unit Rate</th>
                    <th className="p-3 font-semibold text-right w-24">Subtotal</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-200 text-zinc-800">
                  {selectedInvoice.items.map((item) => (
                    <tr key={item.id}>
                      <td className="p-3 font-medium">
                        {item.description}
                        <span className="block text-[9px] text-zinc-400 mt-0.5">SAC: 998311 - Tech Platform integration</span>
                      </td>
                      <td className="p-3 text-center font-mono">{item.quantity}</td>
                      <td className="p-3 text-right font-mono">₹{item.rate.toLocaleString("en-IN")}</td>
                      <td className="p-3 text-right font-mono">₹{(item.quantity * item.rate).toLocaleString("en-IN")}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* printable tax block summaries */}
            <div className="flex justify-between items-start pt-4 text-xs border-t">
              <div className="max-w-[50%] space-y-1 text-[10px] text-zinc-500 leading-normal">
                <h5 className="font-bold text-zinc-900 uppercase tracking-wider">Declarations & Payment terms</h5>
                <p>1. Please transfer outstanding payments within the designated net-30 ledger date.</p>
                <p>2. Subject to late transaction fee adjustments of 1.5% compounding weekly.</p>
                <p>Thank you for letting AI Business OS power your billing cycles.</p>
              </div>

              <div className="w-64 space-y-2 text-xs">
                {/* Math breakdown */}
                {(() => {
                  const subVal = selectedInvoice.items.reduce((sum, item) => sum + item.quantity * item.rate, 0);
                  const discVal = selectedInvoice.discount;
                  const taxBase = Math.max(0, subVal - discVal);
                  const gstVal = taxBase * (selectedInvoice.gstRate / 100);

                  return (
                    <>
                      <div className="flex justify-between text-zinc-500">
                        <span>Items Subtotal:</span>
                        <span className="font-mono">₹{subVal.toLocaleString("en-IN")}</span>
                      </div>
                      {discVal > 0 && (
                        <div className="flex justify-between text-rose-500">
                          <span>Applied discounts:</span>
                          <span className="font-mono">-₹{discVal.toLocaleString("en-IN")}</span>
                        </div>
                      )}
                      <div className="flex justify-between text-zinc-500">
                        <span>Taxable base:</span>
                        <span className="font-mono">₹{taxBase.toLocaleString("en-IN")}</span>
                      </div>
                      <div className="flex justify-between text-zinc-500">
                        <span>Output IGST ({selectedInvoice.gstRate}%):</span>
                        <span className="font-mono">₹{gstVal.toLocaleString("en-IN")}</span>
                      </div>
                      <div className="flex justify-between border-t pt-2 font-bold text-sm text-zinc-900">
                        <span>Grand Total Due:</span>
                        <span className="font-mono text-indigo-600 text-base">₹{selectedInvoice.total.toLocaleString("en-IN")}</span>
                      </div>
                    </>
                  );
                })()}
              </div>
            </div>

            {/* signature fields block */}
            <div className="flex justify-between items-end pt-12 text-xs">
              <div>
                <span className="block text-[8px] font-bold text-zinc-400 uppercase tracking-widest mb-4">Customer Acknowledgement:</span>
                <div className="w-40 border-b border-zinc-300 h-6"></div>
                <span className="text-[9px] text-zinc-400 mt-1 block">Authorized signee</span>
              </div>
              <div className="text-right">
                <span className="block text-[8px] font-bold text-zinc-400 uppercase tracking-widest mb-4">For AI Business OS Ltd:</span>
                <div className="font-mono italic font-bold text-indigo-600 pr-4">AI Copilot Signed</div>
                <div className="w-40 border-b border-zinc-300 h-2 ml-auto"></div>
                <span className="text-[9px] text-zinc-400 mt-1 block">Authorized accountant system</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
