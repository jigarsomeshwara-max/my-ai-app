import React, { useState } from "react";
import { ClientCRM } from "../types";
import { Plus, Check, Mail, Phone, Building, Briefcase, Wand2, ShieldAlert, AlertCircle, Sparkles, X } from "lucide-react";

interface CRMViewProps {
  clients: ClientCRM[];
  onAddClient: (client: ClientCRM) => void;
  onUpdateClient: (client: ClientCRM) => void;
  theme: "light" | "dark";
}

export default function CRMView({ clients, onAddClient, onUpdateClient, theme }: CRMViewProps) {
  const [showAddForm, setShowAddForm] = useState(false);
  const [selectedClient, setSelectedClient] = useState<ClientCRM | null>(null);
  
  // New Client Form States
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [company, setCompany] = useState("");
  const [value, setValue] = useState("");
  const [status, setStatus] = useState<any>("Lead");
  const [notes, setNotes] = useState("");

  // AI strategy states
  const [generatingStrategy, setGeneratingStrategy] = useState(false);
  const [strategyOutput, setStrategyOutput] = useState("");

  const handleCreateClient = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email) return;

    const newClient: ClientCRM = {
      id: "crm-" + Date.now(),
      name,
      email,
      phone: phone || "+91 00000 00000",
      company: company || "Independent",
      value: parseFloat(value) || 0,
      status,
      notes: notes || "Initial lead capture.",
      lastActive: new Date().toISOString().split("T")[0]
    };

    onAddClient(newClient);
    setShowAddForm(false);
    setSelectedClient(newClient);
    setStrategyOutput("");

    // reset
    setName("");
    setEmail("");
    setPhone("");
    setCompany("");
    setValue("");
    setStatus("Lead");
    setNotes("");
  };

  const handleFetchStrategy = async (client: ClientCRM) => {
    setGeneratingStrategy(true);
    setStrategyOutput("");

    try {
      const response = await fetch("/api/ai/crm-insights", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: client.name,
          notes: client.notes,
          value: client.value,
          status: client.status
        })
      });

      const data = await response.json();
      setGeneratingStrategy(false);

      if (data.success && data.text) {
        setStrategyOutput(data.text);
        onUpdateClient({
          ...client,
          insights: data.text
        });
      } else {
        setStrategyOutput("Failed to fetch custom follow-up copy. Simulator text: Always outline clear milestones and follow up with Suresh tomorrow morning offering a free workspace audit.");
      }
    } catch (err) {
      setGeneratingStrategy(false);
      setStrategyOutput("Error reaching server node. Simulating outreach template:\n\nDear " + client.name + ",\n\nI enjoyed reviewing your operational notes. Let's schedule a 10-minute demo to map your exact GST parameters. Best, सुरेश");
    }
  };

  return (
    <div className="flex-1 overflow-y-auto space-y-6 pr-1 h-full">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-sans font-extrabold tracking-tight">Customer CRM Pipeline</h2>
          <p className="text-xs text-zinc-500 font-medium">Manage corporate leads, track deal pipelines, and generate AI follow-up campaigns.</p>
        </div>

        <button
          onClick={() => setShowAddForm(true)}
          className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 shadow"
          id="btn-crm-new"
        >
          <Plus className="w-4 h-4" />
          <span>Capture New Lead</span>
        </button>
      </div>

      {/* Main double panel container */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left column: Leads index table */}
        <div className={`lg:col-span-2 border rounded-2xl overflow-hidden ${
          theme === "dark" ? "bg-zinc-900 border-zinc-800" : "bg-white border-zinc-200 shadow-sm"
        }`}>
          <div className="p-4 border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-between">
            <h3 className="font-sans font-bold text-xs uppercase tracking-wider text-zinc-400">Prospect Pipeline</h3>
            <span className="text-[10px] font-mono font-bold text-zinc-400">Total: {clients.length} accounts</span>
          </div>

          <div className="divide-y divide-zinc-200 dark:divide-zinc-800">
            {clients.map((client) => (
              <div
                key={client.id}
                onClick={() => {
                  setSelectedClient(client);
                  setStrategyOutput(client.insights || "");
                }}
                className={`p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 cursor-pointer transition ${
                  selectedClient?.id === client.id 
                    ? theme === "dark" ? "bg-indigo-950/20" : "bg-indigo-50/50"
                    : "hover:bg-zinc-500/5"
                }`}
                id={`crm-client-row-${client.id}`}
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <h4 className="font-bold text-xs text-zinc-900 dark:text-zinc-100">{client.name}</h4>
                    <span className={`px-2 py-0.5 rounded text-[9px] font-mono font-bold border ${
                      client.status === "Closed"
                        ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-500"
                        : "bg-amber-500/10 border-amber-500/20 text-amber-500"
                    }`}>
                      {client.status}
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-x-3 gap-y-1 text-[10px] text-zinc-500 font-medium">
                    <span className="flex items-center gap-1"><Building className="w-3.5 h-3.5 text-zinc-400" /> {client.company}</span>
                    <span className="flex items-center gap-1"><Mail className="w-3.5 h-3.5 text-zinc-400" /> {client.email}</span>
                  </div>
                </div>

                <div className="flex items-center gap-4 justify-between md:justify-end">
                  <div className="text-left md:text-right">
                    <span className="text-[9px] font-bold text-zinc-400 uppercase tracking-widest block font-mono">Deal pool</span>
                    <strong className="text-xs font-mono text-zinc-800 dark:text-zinc-200">₹{client.value.toLocaleString("en-IN")}</strong>
                  </div>
                  <div className="w-7 h-7 rounded-full bg-zinc-500/10 text-zinc-400 flex items-center justify-center text-xs font-bold border border-zinc-500/15">
                    {client.name.split(" ").map(n => n[0]).join("")}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right column: Action strategy & details panel */}
        <div className="space-y-6">
          {selectedClient ? (
            <div className={`p-5 rounded-2xl border space-y-4 ${
              theme === "dark" ? "bg-zinc-900 border-zinc-800" : "bg-white border-zinc-200 shadow-sm"
            }`}>
              <div className="flex items-center justify-between border-b pb-2">
                <div>
                  <h3 className="font-sans font-extrabold text-sm tracking-tight">{selectedClient.name}</h3>
                  <span className="text-[10px] text-zinc-400 font-mono mt-0.5 inline-block">{selectedClient.phone}</span>
                </div>
                <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-500">
                  <Sparkles className="w-4 h-4 animate-pulse" />
                </div>
              </div>

              <div className="space-y-3.5">
                <div className="text-xs leading-relaxed space-y-1 text-zinc-500">
                  <h4 className="font-bold text-zinc-400 uppercase tracking-wider text-[9px] font-mono">Operational notes</h4>
                  <p className="italic">"{selectedClient.notes}"</p>
                </div>

                {/* strategy trigger button */}
                <button
                  type="button"
                  onClick={() => handleFetchStrategy(selectedClient)}
                  disabled={generatingStrategy}
                  className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 disabled:opacity-40"
                  id="btn-crm-strategy"
                >
                  {generatingStrategy ? (
                    <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      <Wand2 className="w-3.5 h-3.5" />
                      <span>Generate AI Closing Campaign</span>
                    </>
                  )}
                </button>

                {strategyOutput && (
                  <div className="border-t border-zinc-200 dark:border-zinc-800 pt-3.5 space-y-3">
                    <h4 className="text-[9px] font-bold text-indigo-500 uppercase tracking-widest font-mono flex items-center gap-1">
                      <Sparkles className="w-3 h-3 animate-pulse" />
                      <span>Gemini closing playbook</span>
                    </h4>

                    <div className={`p-3.5 rounded-xl border text-[11px] font-mono leading-relaxed space-y-2 whitespace-pre-line ${
                      theme === "dark" ? "bg-zinc-950/60 border-zinc-800 text-zinc-300" : "bg-zinc-50 border-zinc-200 text-zinc-700"
                    }`}>
                      {strategyOutput}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className={`p-6 rounded-2xl border text-center space-y-3 ${
              theme === "dark" ? "bg-zinc-900 border-zinc-800 text-zinc-400" : "bg-white border-zinc-200 shadow-sm text-zinc-500"
            }`}>
              <AlertCircle className="w-8 h-8 mx-auto text-zinc-400" />
              <div>
                <h4 className="font-sans font-bold text-xs">No client focus</h4>
                <p className="text-[10px] text-zinc-500 mt-1">Select a prospect from the pipeline register to map custom AI closing blueprints.</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Add Lead overlay modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className={`w-full max-w-lg rounded-2xl border p-6 space-y-4 shadow-2xl overflow-y-auto max-h-[90vh] ${
            theme === "dark" ? "bg-zinc-900 border-zinc-800 text-white" : "bg-white border-zinc-200 text-zinc-900"
          }`}>
            <div className="flex items-center justify-between border-b pb-2">
              <h3 className="font-sans font-extrabold text-base tracking-tight">Capture Corporate Prospect</h3>
              <button 
                onClick={() => setShowAddForm(false)} 
                className="p-1 rounded-lg text-zinc-400 hover:bg-zinc-500/10 transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateClient} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[9px] font-bold uppercase tracking-wider text-zinc-400 mb-1">Prospect Name</label>
                  <input
                    type="text"
                    required
                    placeholder="Siddharth Roy"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className={`w-full p-2 rounded-xl border focus:outline-none ${
                      theme === "dark" ? "bg-zinc-950 border-zinc-800 text-white" : "bg-zinc-50 border-zinc-200 text-zinc-900"
                    }`}
                  />
                </div>
                <div>
                  <label className="block text-[9px] font-bold uppercase tracking-wider text-zinc-400 mb-1">Company Entity</label>
                  <input
                    type="text"
                    placeholder="Roy Enterprise"
                    value={company}
                    onChange={(e) => setCompany(e.target.value)}
                    className={`w-full p-2 rounded-xl border focus:outline-none ${
                      theme === "dark" ? "bg-zinc-950 border-zinc-800 text-white" : "bg-zinc-50 border-zinc-200 text-zinc-900"
                    }`}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[9px] font-bold uppercase tracking-wider text-zinc-400 mb-1">Email Address</label>
                  <input
                    type="email"
                    required
                    placeholder="siddharth@roy.co"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className={`w-full p-2 rounded-xl border focus:outline-none ${
                      theme === "dark" ? "bg-zinc-950 border-zinc-800 text-white" : "bg-zinc-50 border-zinc-200 text-zinc-900"
                    }`}
                  />
                </div>
                <div>
                  <label className="block text-[9px] font-bold uppercase tracking-wider text-zinc-400 mb-1">Phone Number</label>
                  <input
                    type="text"
                    placeholder="+91 99887 76655"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className={`w-full p-2 rounded-xl border focus:outline-none ${
                      theme === "dark" ? "bg-zinc-950 border-zinc-800 text-white" : "bg-zinc-50 border-zinc-200 text-zinc-900"
                    }`}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[9px] font-bold uppercase tracking-wider text-zinc-400 mb-1">Estimated Contract Pool (₹)</label>
                  <input
                    type="number"
                    placeholder="250000"
                    value={value}
                    onChange={(e) => setValue(e.target.value)}
                    className={`w-full p-2 rounded-xl border focus:outline-none ${
                      theme === "dark" ? "bg-zinc-950 border-zinc-800 text-white" : "bg-zinc-50 border-zinc-200 text-zinc-900"
                    }`}
                  />
                </div>
                <div>
                  <label className="block text-[9px] font-bold uppercase tracking-wider text-zinc-400 mb-1">Initial Status</label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value)}
                    className={`w-full p-2 rounded-xl border focus:outline-none ${
                      theme === "dark" ? "bg-zinc-950 border-zinc-800 text-white" : "bg-zinc-50 border-zinc-200 text-zinc-900"
                    }`}
                  >
                    <option value="Lead">Lead Capture</option>
                    <option value="Contacted">Contacted / Pitch Made</option>
                    <option value="Warm">Warm Negotiations</option>
                    <option value="Qualified">Qualified Deal</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[9px] font-bold uppercase tracking-wider text-zinc-400 mb-1">Sales/Requirement Notes</label>
                <textarea
                  placeholder="Need custom dashboard capabilities. Transitioning from legacy Salesforce subscription."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className={`w-full h-20 p-2.5 rounded-xl border focus:outline-none leading-relaxed ${
                    theme === "dark" ? "bg-zinc-950 border-zinc-800 text-white" : "bg-zinc-50 border-zinc-200 text-zinc-900"
                  }`}
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow-lg transition"
                id="btn-crm-modal-submit"
              >
                Capture Account Record
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
