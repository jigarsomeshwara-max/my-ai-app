import React, { useState, useEffect } from "react";
import { 
  INITIAL_CLIENTS, 
  INITIAL_INVOICES, 
  INITIAL_EXPENSES, 
  INITIAL_LOGS 
} from "./data";
import { ChatMessage } from "./types";
import { 
  UserProfile, 
  Invoice, 
  Expense, 
  ClientCRM, 
  PushNotification, 
  SystemLog 
} from "./types";

// Components
import DeviceShell from "./components/DeviceShell";
import AuthView from "./components/AuthView";
import DashboardView from "./components/DashboardView";
import AIChatView from "./components/AIChatView";
import InvoiceView from "./components/InvoiceView";
import ExpenseTrackerView from "./components/ExpenseTrackerView";
import CRMView from "./components/CRMView";
import MarketingAIView from "./components/MarketingAIView";
import SEOBlogView from "./components/SEOBlogView";
import ReportsView from "./components/ReportsView";
import SubscriptionView from "./components/SubscriptionView";
import NotificationsPanel from "./components/NotificationsPanel";
import AdminPanel from "./components/AdminPanel";
import FlutterSDKCenter from "./components/FlutterSDKCenter";

// Icons
import { 
  LayoutDashboard, 
  MessageSquare, 
  FileText, 
  Receipt, 
  Users, 
  Share2, 
  BookOpen, 
  BarChart2, 
  CreditCard, 
  Bell, 
  Terminal, 
  Code,
  Moon,
  Sun,
  Laptop,
  Smartphone,
  Sparkles,
  LogOut,
  X,
  Menu
} from "lucide-react";

export default function App() {
  // Global states
  const [user, setUser] = useState<UserProfile | null>(null);
  const [theme, setTheme] = useState<"light" | "dark">("dark");
  const [device, setDevice] = useState<"web" | "iphone" | "android">("web");
  const [activeTab, setActiveTab] = useState<string>("dashboard");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [webSidebarOpen, setWebSidebarOpen] = useState(false);

  // Initial notifications list
  const INITIAL_NOTIFICATIONS: PushNotification[] = [
    {
      id: "notif-1",
      title: "GST Invoice Paid",
      body: "Das Creative Studio paid INV-2026-002 total ₹42,480.",
      type: "billing",
      time: "2 hours ago",
      read: true
    },
    {
      id: "notif-2",
      title: "New Lead Acquired",
      body: "Aarav Sharma qualified as a warm lead via LinkedIn widget.",
      type: "crm",
      time: "4 hours ago",
      read: false
    },
    {
      id: "notif-3",
      title: "FCM Push Synchronized",
      body: "Push broadcast server successfully authenticated with sandbox device.",
      type: "system",
      time: "1 day ago",
      read: true
    }
  ];

  // Collections states
  const [invoices, setInvoices] = useState<Invoice[]>(INITIAL_INVOICES);
  const [expenses, setExpenses] = useState<Expense[]>(INITIAL_EXPENSES);
  const [clients, setClients] = useState<ClientCRM[]>(INITIAL_CLIENTS);
  const [notifications, setNotifications] = useState<PushNotification[]>(INITIAL_NOTIFICATIONS);
  const [logs, setLogs] = useState<SystemLog[]>(INITIAL_LOGS);
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);

  // Push notifications banner trigger
  const [activeToast, setActiveToast] = useState<{ title: string; body: string } | null>(null);

  // Trigger push alert banner
  const triggerPushBanner = (title: string, body: string, type: "crm" | "billing" | "security" | "system") => {
    // 1. Add to alert list
    const newNotif: PushNotification = {
      id: "notif-" + Date.now(),
      title,
      body,
      type,
      time: "Just now",
      read: false
    };
    setNotifications(prev => [newNotif, ...prev]);

    // 2. Add to server logs
    addSystemLog("FCM", `Push broadcasted: "${title}" - Type: ${type}`, "success");

    // 3. Trigger screen slide-down
    setActiveToast({ title, body });
  };

  const addSystemLog = (service: string, message: string, type: "success" | "warning" | "info" = "info") => {
    const newLog: SystemLog = {
      id: "log-" + Date.now(),
      timestamp: new Date().toLocaleTimeString(),
      service,
      message,
      type
    };
    setLogs(prev => [newLog, ...prev]);
  };

  // Close live slide toast
  useEffect(() => {
    if (activeToast) {
      const timer = setTimeout(() => {
        setActiveToast(null);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [activeToast]);

  // Auth logins
  const handleLogin = (u: UserProfile) => {
    setUser(u);
    addSystemLog("AUTH", `Authorized login session for ${u.name} (${u.email})`, "success");
  };

  const handleLogout = () => {
    setUser(null);
    addSystemLog("AUTH", "Closed session token.", "warning");
  };

  // Upgrades plan
  const handleUpdatePlan = (newPlan: "Free" | "Pro" | "Enterprise") => {
    if (user) {
      setUser({ ...user, plan: newPlan });
      addSystemLog("SUBSCRIBE", `Razorpay verified transaction. Session package elevated to ${newPlan}.`, "success");
      triggerPushBanner(
        "Subscription Upgraded",
        `Welcome to the ${newPlan} cluster tier! Premium SDK compilation modules unlocked.`,
        "billing"
      );
    }
  };

  // Workspace Nav Options
  const navigationItems = [
    { id: "dashboard", label: "Executive Dashboard", icon: <LayoutDashboard className="w-4 h-4" /> },
    { id: "ai-chat", label: "AI Business Chat", icon: <MessageSquare className="w-4 h-4 text-cyan-400" /> },
    { id: "invoices", label: "GST Invoice Engine", icon: <FileText className="w-4 h-4" /> },
    { id: "expenses", label: "Expense Auditor", icon: <Receipt className="w-4 h-4" /> },
    { id: "crm", label: "CRM Deal Pipeline", icon: <Users className="w-4 h-4" /> },
    { id: "marketing", label: "Marketing AI", icon: <Share2 className="w-4 h-4" /> },
    { id: "blog", label: "SEO Blog Writer", icon: <BookOpen className="w-4 h-4" /> },
    { id: "reports", label: "Business Reports", icon: <BarChart2 className="w-4 h-4" /> },
    { id: "subscription", label: "Razorpay Billing", icon: <CreditCard className="w-4 h-4" /> },
    { id: "notifications", label: "FCM Push alerts", icon: <Bell className="w-4 h-4" /> },
    { id: "sdk", label: "Developer SDK Export", icon: <Code className="w-4 h-4 text-emerald-400" /> },
    { id: "admin", label: "System Telemetry", icon: <Terminal className="w-4 h-4" /> },
  ];

  const handleAddInvoice = (newInv: Invoice) => {
    setInvoices(prev => [newInv, ...prev]);
    addSystemLog("INVOICE", `Created invoice #${newInv.invoiceNumber} for ${newInv.clientName}`, "success");
    triggerPushBanner(
      "Invoice Dispatched",
      `GST Invoice #${newInv.invoiceNumber} has been recorded to database. Base: ₹${newInv.total}`,
      "billing"
    );
  };

  const handleAddExpense = (newExp: Expense) => {
    setExpenses(prev => [newExp, ...prev]);
    addSystemLog("EXPENSE", `Recorded operating cost: ₹${newExp.amount} from ${newExp.vendor}`, "success");
    triggerPushBanner(
      "Overhead Recorded",
      `New expense entry mapped to Category: ${newExp.category} for ₹${newExp.amount}`,
      "billing"
    );
  };

  const handleAddClient = (newC: ClientCRM) => {
    setClients(prev => [newC, ...prev]);
    addSystemLog("CRM", `Captured new lead: ${newC.name} - Deal value: ₹${newC.value}`, "success");
    triggerPushBanner(
      "Prospect Acquired",
      `${newC.name} added to pipeline under ${newC.company}. Value pool: ₹${newC.value}`,
      "crm"
    );
  };

  const handleUpdateClient = (updatedC: ClientCRM) => {
    setClients(prev => prev.map(c => c.id === updatedC.id ? updatedC : c));
    addSystemLog("CRM", `Recalculated campaign playbooks for ${updatedC.name}`, "info");
  };

  const handleAddChatMessage = (msg: ChatMessage) => {
    setChatHistory(prev => [...prev, msg]);
  };

  const handleClearChatHistory = () => {
    setChatHistory([]);
  };

  return (
    <div className={`min-h-screen flex flex-col font-sans transition-all duration-300 ${
      theme === "dark" ? "bg-zinc-950 text-zinc-100" : "bg-zinc-100 text-zinc-800"
    }`} id="app-viewport">
      
      {/* Dynamic Slide-down Push Banner Notification */}
      {activeToast && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 animate-bounce max-w-sm w-full bg-indigo-600 text-white rounded-2xl shadow-2xl p-4 border border-indigo-500/30 flex items-start gap-3">
          <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center text-white flex-shrink-0 animate-pulse">
            <Bell className="w-4.5 h-4.5" />
          </div>
          <div className="flex-1 space-y-0.5">
            <h5 className="font-extrabold text-xs tracking-tight">{activeToast.title}</h5>
            <p className="text-[10.5px] text-zinc-100 leading-normal font-mono">{activeToast.body}</p>
          </div>
          <button 
            onClick={() => setActiveToast(null)} 
            className="p-1 rounded bg-white/10 hover:bg-white/20 text-white"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Global Command Bar Header (Invisible to output device, helps previewers) */}
      <header className="hidden md:flex p-3.5 border-b border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 flex-wrap gap-4 items-center justify-between z-40">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-indigo-600 rounded-xl text-white">
            <Sparkles className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h1 className="text-sm font-sans font-extrabold tracking-tight">AI Business OS Console</h1>
            <p className="text-[10px] text-zinc-500 font-mono">Cross-Platform (Web + iOS + Android) Play Ground</p>
          </div>
        </div>

        {/* System toggles */}
        <div className="flex items-center gap-3">
          {/* Frame Selectors */}
          <div className="flex items-center gap-1 rounded-xl bg-zinc-100 dark:bg-zinc-950 p-1 border border-zinc-200 dark:border-zinc-800">
            <button
              onClick={() => setDevice("web")}
              className={`p-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1 ${
                device === "web" ? "bg-indigo-600 text-white shadow" : "text-zinc-500 hover:text-zinc-300"
              }`}
              title="MacBook Web Layout"
              id="btn-frame-web"
            >
              <Laptop className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Web Workspace</span>
            </button>
            <button
              onClick={() => setDevice("iphone")}
              className={`p-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1 ${
                device === "iphone" ? "bg-indigo-600 text-white shadow" : "text-zinc-500 hover:text-zinc-300"
              }`}
              title="iPhone Simulator Layout"
              id="btn-frame-iphone"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">iOS Frame</span>
            </button>
            <button
              onClick={() => setDevice("android")}
              className={`p-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1 ${
                device === "android" ? "bg-indigo-600 text-white shadow" : "text-zinc-500 hover:text-zinc-300"
              }`}
              title="Android Material 3 Simulator"
              id="btn-frame-android"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Android M3</span>
            </button>
          </div>

          {/* Theme toggler */}
          <button
            onClick={() => setTheme(theme === "light" ? "dark" : "light")}
            className="p-2 rounded-xl bg-zinc-150 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 text-zinc-500 transition hover:text-indigo-500"
            id="btn-theme-toggle"
          >
            {theme === "light" ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
          </button>
        </div>
      </header>

      {/* Main Sandbox Frame Rendering */}
      <main className="flex-1 flex items-center justify-center p-3 sm:p-6 overflow-hidden">
        <DeviceShell 
          activeDevice={device} 
          onChangeDevice={setDevice} 
          theme={theme} 
          onToggleTheme={() => setTheme(prev => prev === "light" ? "dark" : "light")}
        >
          
          {/* Internal Application Core */}
          {!user ? (
            <AuthView onLoginSuccess={handleLogin} theme={theme} />
          ) : (
            <div className="flex flex-col lg:flex-row h-full overflow-hidden w-full relative">
              
              {/* Mobile Header for Web Workspace */}
              {device === "web" && (
                <div className="lg:hidden flex items-center justify-between p-3 border-b border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 w-full z-30 flex-shrink-0" id="web-mobile-header">
                  <div className="flex items-center gap-2">
                    <button 
                      onClick={() => setWebSidebarOpen(true)}
                      className="p-2 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 border border-zinc-200 dark:border-zinc-700 hover:text-indigo-500"
                      id="btn-web-hamburger"
                    >
                      <Menu className="w-4.5 h-4.5" />
                    </button>
                    <span className="font-sans font-extrabold text-xs tracking-tight">AI Business OS</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[9px] font-bold text-indigo-500 font-mono bg-indigo-500/10 px-1.5 py-0.5 rounded uppercase">
                      {user.plan} Node
                    </span>
                  </div>
                </div>
              )}

              {/* Sidebar layout (For Web workspace) */}
              {device === "web" && (
                <>
                  {/* Backdrop for mobile drawer */}
                  {webSidebarOpen && (
                    <div 
                      className="lg:hidden fixed inset-0 bg-black/60 backdrop-blur-xs z-40 transition-opacity"
                      onClick={() => setWebSidebarOpen(false)}
                      id="sidebar-backdrop"
                    />
                  )}

                  <aside className={`
                    w-64 border-r flex flex-col justify-between p-4 flex-shrink-0 transition-transform duration-300 z-50
                    ${theme === "dark" ? "bg-zinc-950 border-zinc-800" : "bg-white border-zinc-200"}
                    lg:static lg:translate-x-0 lg:flex
                    fixed inset-y-0 left-0 h-full
                    ${webSidebarOpen ? "translate-x-0" : "-translate-x-full"}
                  `} id="sidebar-drawer">
                    <div className="space-y-6 overflow-y-auto max-h-[calc(100%-60px)]">
                      {/* User profile capsule */}
                      <div className="flex items-center justify-between border-b pb-3.5">
                        <div className="flex items-center gap-2.5">
                          <div className="w-9 h-9 rounded-full bg-indigo-600 flex items-center justify-center text-white font-extrabold text-sm border border-indigo-500">
                            SK
                          </div>
                          <div className="leading-tight">
                            <span className="font-bold text-xs block text-zinc-900 dark:text-zinc-100">{user.name}</span>
                            <span className="text-[10px] text-zinc-500 block">{user.email}</span>
                            <span className="text-[9px] font-bold text-indigo-500 mt-1 uppercase font-mono bg-indigo-500/10 px-1.5 py-0.5 rounded inline-block">
                              {user.plan} Node Active
                            </span>
                          </div>
                        </div>
                        <button 
                          onClick={() => setWebSidebarOpen(false)}
                          className="lg:hidden p-1.5 rounded-lg hover:bg-zinc-500/10 text-zinc-400"
                          id="btn-close-web-sidebar"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>

                      {/* Navigation Options list */}
                      <nav className="space-y-1">
                        {navigationItems.map((item) => (
                          <button
                            key={item.id}
                            onClick={() => {
                              setActiveTab(item.id);
                              setWebSidebarOpen(false);
                            }}
                            className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-bold transition text-left ${
                              activeTab === item.id
                                ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/10"
                                : theme === "dark"
                                  ? "text-zinc-400 hover:bg-zinc-900 hover:text-zinc-200"
                                  : "text-zinc-600 hover:bg-zinc-100 hover:text-zinc-900"
                            }`}
                            id={`nav-item-${item.id}`}
                          >
                            {item.icon}
                            <span>{item.label}</span>
                          </button>
                        ))}
                      </nav>
                    </div>

                    {/* Sidebar Footer Logout */}
                    <button
                      onClick={handleLogout}
                      className="w-full py-2 border border-rose-500/20 hover:bg-rose-500/10 text-rose-500 text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 mt-auto"
                      id="btn-sidebar-logout"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>Terminate Session</span>
                    </button>
                  </aside>
                </>
              )}

              {/* Mobile device frame support (Phone layouts gets bottom tab navigation style) */}
              {device !== "web" && (
                <div className="absolute top-0 inset-x-0 h-12 border-b z-30 flex items-center justify-between px-3.5 bg-zinc-900 text-white border-zinc-800">
                  <div className="flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-indigo-400 animate-pulse" />
                    <span className="font-sans font-extrabold text-xs tracking-tight">AI Business OS</span>
                  </div>

                  <div className="flex items-center gap-1">
                    <button 
                      onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                      className="p-1.5 rounded-lg bg-zinc-800 text-zinc-300"
                      id="btn-mobile-menu"
                    >
                      <Menu className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}

              {/* Floating Mobile Nav bar modal */}
              {mobileMenuOpen && device !== "web" && (
                <div className="absolute inset-0 bg-black/90 z-40 p-4 overflow-y-auto space-y-4 flex flex-col justify-between">
                  <div className="space-y-4">
                    <div className="flex justify-between items-center border-b border-zinc-800 pb-2">
                      <span className="text-xs font-extrabold font-mono text-zinc-400">Navigation Hub</span>
                      <button onClick={() => setMobileMenuOpen(false)} className="p-1.5 rounded bg-zinc-800 text-zinc-400">
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      {navigationItems.map((item) => (
                        <button
                          key={item.id}
                          onClick={() => {
                            setActiveTab(item.id);
                            setMobileMenuOpen(false);
                          }}
                          className={`flex items-center gap-2 p-2.5 rounded-xl border text-[11px] font-bold text-left transition ${
                            activeTab === item.id
                              ? "bg-indigo-600 text-white border-indigo-600"
                              : "bg-zinc-900 border-zinc-800 text-zinc-300"
                          }`}
                          id={`mobile-nav-item-${item.id}`}
                        >
                          {item.icon}
                          <span>{item.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      handleLogout();
                      setMobileMenuOpen(false);
                    }}
                    className="w-full py-2.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl text-center"
                  >
                    Close Session Token
                  </button>
                </div>
              )}

               {/* Core active workspace body */}
              <div className={`flex-1 p-3 sm:p-6 overflow-hidden flex flex-col h-full min-h-0 ${
                device !== "web" ? "pt-14 pb-4" : ""
              }`}>
                {activeTab === "dashboard" && (
                  <DashboardView 
                    invoices={invoices} 
                    expenses={expenses} 
                    clients={clients} 
                    onNavigate={(tab) => setActiveTab(tab)}
                    theme={theme} 
                  />
                )}

                {activeTab === "ai-chat" && (
                  <AIChatView 
                    chatHistory={chatHistory} 
                    onAddMessage={handleAddChatMessage} 
                    onClearHistory={handleClearChatHistory} 
                    theme={theme} 
                  />
                )}

                {activeTab === "invoices" && (
                  <InvoiceView 
                    invoices={invoices} 
                    onAddInvoice={handleAddInvoice} 
                    theme={theme} 
                  />
                )}

                {activeTab === "expenses" && (
                  <ExpenseTrackerView 
                    expenses={expenses} 
                    onAddExpense={handleAddExpense} 
                    theme={theme} 
                  />
                )}

                {activeTab === "crm" && (
                  <CRMView 
                    clients={clients} 
                    onAddClient={handleAddClient} 
                    onUpdateClient={handleUpdateClient} 
                    theme={theme} 
                  />
                )}

                {activeTab === "marketing" && (
                  <MarketingAIView theme={theme} />
                )}

                {activeTab === "blog" && (
                  <SEOBlogView theme={theme} />
                )}

                {activeTab === "reports" && (
                  <ReportsView 
                    invoices={invoices} 
                    expenses={expenses} 
                    theme={theme} 
                  />
                )}

                {activeTab === "subscription" && (
                  <SubscriptionView 
                    user={user} 
                    onUpdatePlan={handleUpdatePlan} 
                    theme={theme} 
                  />
                )}

                {activeTab === "notifications" && (
                  <NotificationsPanel 
                    notifications={notifications} 
                    onMarkRead={(id) => setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n))}
                    onClearAll={() => setNotifications([])}
                    onSimulateNotification={triggerPushBanner}
                    theme={theme} 
                  />
                )}

                {activeTab === "sdk" && (
                  <FlutterSDKCenter theme={theme} />
                )}

                {activeTab === "admin" && (
                  <AdminPanel 
                    user={user} 
                    onUpdatePlan={handleUpdatePlan} 
                    logs={logs} 
                    onClearLogs={() => setLogs([])}
                    theme={theme} 
                  />
                )}
              </div>

            </div>
          )}

        </DeviceShell>
      </main>

    </div>
  );
}
