import React from "react";
import { Invoice, Expense } from "../types";
import { BarChart, PieChart, ShieldAlert, FileText, ArrowRight, TrendingUp, HelpCircle } from "lucide-react";

interface ReportsViewProps {
  invoices: Invoice[];
  expenses: Expense[];
  theme: "light" | "dark";
}

export default function ReportsView({ invoices, expenses, theme }: ReportsViewProps) {
  // Financial computations
  const totalInvoiced = invoices.reduce((sum, inv) => sum + inv.total, 0);
  const totalPaid = invoices.filter(i => i.status === "Paid").reduce((sum, inv) => sum + inv.total, 0);
  const totalOverage = expenses.reduce((sum, exp) => sum + exp.amount, 0);
  const netEarnings = totalPaid - totalOverage;

  const totalGSTCollected = invoices
    .filter(i => i.status === "Paid")
    .reduce((sum, inv) => {
      const base = inv.items.reduce((s, it) => s + it.quantity * it.rate, 0) - inv.discount;
      return sum + (Math.max(0, base) * (inv.gstRate / 100));
    }, 0);

  const totalGSTInputPaid = expenses.reduce((sum, exp) => sum + exp.gstAmount, 0);
  const netGSTLiability = Math.round(Math.max(0, totalGSTCollected - totalGSTInputPaid));

  // Category distributions for SVG pie chart
  const categoriesMap: { [key: string]: number } = {};
  expenses.forEach((e) => {
    categoriesMap[e.category] = (categoriesMap[e.category] || 0) + e.amount;
  });

  const categories = Object.keys(categoriesMap).map((cat) => ({
    name: cat,
    value: categoriesMap[cat],
  }));

  const totalCatValues = categories.reduce((sum, c) => sum + c.value, 0);

  // SVG colors
  const colors = ["#4f46e5", "#f43f5e", "#06b6d4", "#eab308", "#a855f7"];

  return (
    <div className="flex-1 overflow-y-auto space-y-6 pr-1 h-full">
      <div>
        <h2 className="text-xl font-sans font-extrabold tracking-tight">Executive Business Reports</h2>
        <p className="text-xs text-zinc-500 font-medium">Reconcile service taxes, audit operational balances, and view profitability forecasts.</p>
      </div>

      {/* Grid summarizing auditing tax vectors */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className={`p-4 rounded-2xl border ${
          theme === "dark" ? "bg-zinc-900 border-zinc-800" : "bg-white border-zinc-200 shadow-sm"
        }`}>
          <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest block font-mono">Output IGST Collected</span>
          <h3 className="text-lg font-bold font-mono text-emerald-500 mt-1">₹{Math.round(totalGSTCollected).toLocaleString("en-IN")}</h3>
          <span className="text-[10px] text-zinc-500 mt-0.5 block">From fully paid client invoices</span>
        </div>

        <div className={`p-4 rounded-2xl border ${
          theme === "dark" ? "bg-zinc-900 border-zinc-800" : "bg-white border-zinc-200 shadow-sm"
        }`}>
          <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest block font-mono">Input GST Paid Credit</span>
          <h3 className="text-lg font-bold font-mono text-rose-500 mt-1">₹{Math.round(totalGSTInputPaid).toLocaleString("en-IN")}</h3>
          <span className="text-[10px] text-zinc-500 mt-0.5 block">Tax credits claimed on purchases</span>
        </div>

        <div className={`p-4 rounded-2xl border border-indigo-500/20 bg-indigo-500/5 ${
          theme === "dark" ? "" : "shadow-sm"
        }`}>
          <span className="text-[10px] font-bold text-indigo-500 uppercase tracking-widest block font-mono">Net GST Tax Liability</span>
          <h3 className="text-lg font-bold font-mono text-indigo-600 dark:text-indigo-400 mt-1">₹{netGSTLiability.toLocaleString("en-IN")}</h3>
          <span className="text-[10px] text-zinc-500 mt-0.5 block">Net supply liabilities due for filing</span>
        </div>
      </div>

      {/* Main double chart section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* SVG Category allocation donut */}
        <div className={`p-5 rounded-2xl border flex flex-col justify-between ${
          theme === "dark" ? "bg-zinc-900 border-zinc-800" : "bg-white border-zinc-200 shadow-sm"
        }`}>
          <div>
            <h3 className="font-sans font-bold text-sm tracking-tight flex items-center gap-1.5 mb-1">
              <PieChart className="w-4 h-4 text-indigo-500" />
              <span>Overhead Allocations</span>
            </h3>
            <p className="text-[11px] text-zinc-500">Distribution of operating costs by budget category.</p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-6 mt-4">
            {/* SVG circle donut */}
            {categories.length > 0 ? (
              <div className="relative w-36 h-36 flex-shrink-0">
                <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
                  {(() => {
                    let accumulatedPercent = 0;
                    return categories.map((cat, i) => {
                      const percent = cat.value / totalCatValues;
                      const strokeDasharray = `${percent * 251.2} 251.2`;
                      const strokeDashoffset = -accumulatedPercent * 251.2;
                      accumulatedPercent += percent;

                      return (
                        <circle
                          key={i}
                          cx="50"
                          cy="50"
                          r="40"
                          fill="none"
                          stroke={colors[i % colors.length]}
                          strokeWidth="12"
                          strokeDasharray={strokeDasharray}
                          strokeDashoffset={strokeDashoffset}
                          className="transition-all duration-300"
                        />
                      );
                    });
                  })()}
                  {/* inner hole */}
                  <circle cx="50" cy="50" r="28" fill={theme === "dark" ? "#18181b" : "#ffffff"} />
                </svg>
                {/* centered total value overlay */}
                <div className="absolute inset-0 flex flex-col items-center justify-center leading-none text-center">
                  <span className="text-[9px] font-bold text-zinc-400 font-mono uppercase">Total</span>
                  <strong className="text-xs font-mono text-zinc-800 dark:text-zinc-200 mt-1">₹{totalOverage.toLocaleString("en-IN")}</strong>
                </div>
              </div>
            ) : (
              <div className="w-36 h-36 flex items-center justify-center text-zinc-400 text-xs border border-dashed rounded-full">
                No expense entries
              </div>
            )}

            {/* category legends */}
            <div className="flex-1 space-y-2.5 text-[11px] font-medium w-full">
              {categories.map((cat, i) => (
                <div key={i} className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <span 
                      className="w-2.5 h-2.5 rounded-full inline-block flex-shrink-0" 
                      style={{ backgroundColor: colors[i % colors.length] }} 
                    />
                    <span className="text-zinc-500 truncate max-w-[120px]">{cat.name}</span>
                  </div>
                  <strong className="font-mono text-zinc-700 dark:text-zinc-300">
                    {Math.round((cat.value / totalCatValues) * 100)}%
                  </strong>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Profitability forecast graph */}
        <div className={`p-5 rounded-2xl border flex flex-col justify-between ${
          theme === "dark" ? "bg-zinc-900 border-zinc-800" : "bg-white border-zinc-200 shadow-sm"
        }`}>
          <div>
            <h3 className="font-sans font-bold text-sm tracking-tight flex items-center gap-1.5 mb-1">
              <BarChart className="w-4 h-4 text-indigo-500" />
              <span>Projected Operational Growth</span>
            </h3>
            <p className="text-[11px] text-zinc-500">Comparing real invoiced revenue pools with overhead costs.</p>
          </div>

          <div className="space-y-4 mt-6">
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-medium">
                <span className="text-zinc-500">Gross Sales Revenue:</span>
                <strong className="font-mono text-indigo-500">₹{totalPaid.toLocaleString("en-IN")}</strong>
              </div>
              <div className="w-full h-2 rounded-full bg-zinc-500/10 overflow-hidden">
                <div className="h-full bg-indigo-500 rounded-full" style={{ width: `${totalPaid > 0 ? 100 : 0}%` }} />
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-medium">
                <span className="text-zinc-500">Business Overhead:</span>
                <strong className="font-mono text-rose-500">₹{totalOverage.toLocaleString("en-IN")}</strong>
              </div>
              <div className="w-full h-2 rounded-full bg-zinc-500/10 overflow-hidden">
                <div 
                  className="h-full bg-rose-500 rounded-full" 
                  style={{ width: `${totalPaid > 0 ? Math.min(100, (totalOverage / totalPaid) * 100) : 0}%` }} 
                />
              </div>
            </div>

            <div className="space-y-1.5 border-t border-zinc-200 dark:border-zinc-800 pt-3 flex justify-between items-center text-xs">
              <span className="text-zinc-500 font-bold">Net Operational Yield:</span>
              <div className="flex items-center gap-1">
                <TrendingUp className="w-4 h-4 text-emerald-500" />
                <strong className="font-mono text-emerald-500 font-extrabold text-sm">
                  ₹{netEarnings.toLocaleString("en-IN")}
                </strong>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
