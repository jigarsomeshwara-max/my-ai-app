import React, { useState } from "react";
import { Wand2, Share2, Copy, Check, Instagram, Facebook, Linkedin, Youtube, Sparkles } from "lucide-react";

interface MarketingAIViewProps {
  theme: "light" | "dark";
}

export default function MarketingAIView({ theme }: MarketingAIViewProps) {
  const [product, setProduct] = useState("AI Business OS");
  const [channel, setChannel] = useState("LinkedIn");
  const [tone, setTone] = useState("Professional");
  const [details, setDetails] = useState("Automates invoicing, expense logs, CRM, and SEO blogging for solopreneurs.");
  
  const [loading, setLoading] = useState(false);
  const [output, setOutput] = useState("");
  const [copied, setCopied] = useState(false);

  const handleGenerateCopy = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!product || !details) return;

    setLoading(true);
    setOutput("");
    setCopied(false);

    try {
      const response = await fetch("/api/ai/marketing", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ product, channel, tone, details })
      });

      const data = await response.json();
      setLoading(false);

      if (data.success && data.text) {
        setOutput(data.text);
      } else {
        setOutput("Failed to connect to the marketing generator module.");
      }
    } catch (err) {
      setLoading(false);
      setOutput("Error talking to backend Node.js proxy service. Mock content:\n\n🚀 Introducing AI Business OS! Your corporate finance, GST compliance, and CRM pipelines on complete autopilot.\n\n👉 Stop shuffling between spreadsheets and chase payments automatically. Claim your free Pro trial today!");
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex-1 overflow-y-auto space-y-6 pr-1 h-full">
      <div>
        <h2 className="text-xl font-sans font-extrabold tracking-tight">Marketing AI Copywriter</h2>
        <p className="text-xs text-zinc-500 font-medium">Auto-author premium social posts, copy decks, and high-conversion video scripts using Gemini.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* brief param inputs */}
        <div className={`p-5 rounded-2xl border space-y-4 ${
          theme === "dark" ? "bg-zinc-900 border-zinc-800" : "bg-white border-zinc-200 shadow-sm"
        }`}>
          <h3 className="font-sans font-extrabold text-sm border-b pb-2 tracking-tight">Campaign Briefing</h3>

          <form onSubmit={handleGenerateCopy} className="space-y-4 text-xs">
            <div>
              <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                Product or Service Name
              </label>
              <input
                type="text"
                required
                value={product}
                onChange={(e) => setProduct(e.target.value)}
                placeholder="e.g. Zenith Consulting"
                className={`w-full p-2.5 rounded-xl border focus:outline-none focus:ring-1 focus:ring-indigo-500 ${
                  theme === "dark" ? "bg-zinc-950 border-zinc-800 text-white" : "bg-zinc-50 border-zinc-200 text-zinc-900"
                }`}
              />
            </div>

            <div>
              <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                Target Platform Channel
              </label>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { name: "LinkedIn", icon: <Linkedin className="w-3.5 h-3.5" /> },
                  { name: "Instagram", icon: <Instagram className="w-3.5 h-3.5" /> },
                  { name: "Facebook", icon: <Facebook className="w-3.5 h-3.5" /> },
                  { name: "YouTube Script", icon: <Youtube className="w-3.5 h-3.5" /> },
                ].map((item) => (
                  <button
                    type="button"
                    key={item.name}
                    onClick={() => setChannel(item.name)}
                    className={`flex items-center gap-1.5 p-2 rounded-xl border text-left font-semibold transition ${
                      channel === item.name
                        ? "bg-indigo-600 text-white border-indigo-600 shadow"
                        : theme === "dark" 
                          ? "bg-zinc-950 border-zinc-800 text-zinc-300 hover:bg-zinc-900" 
                          : "bg-zinc-50 border-zinc-200 text-zinc-600 hover:bg-zinc-100"
                    }`}
                  >
                    {item.icon}
                    <span>{item.name}</span>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                Tone of Voice
              </label>
              <select
                value={tone}
                onChange={(e) => setTone(e.target.value)}
                className={`w-full p-2 rounded-xl border focus:outline-none ${
                  theme === "dark" ? "bg-zinc-950 border-zinc-800 text-white" : "bg-zinc-50 border-zinc-200 text-zinc-900"
                }`}
              >
                <option value="Professional">Professional / High Authority</option>
                <option value="Creative">Creative / Conversational</option>
                <option value="Empathetic">Empathetic / Solution-Oriented</option>
                <option value="Urgent">Urgent / FOMO-Triggering</option>
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                Key Benefits / Launch Offer
              </label>
              <textarea
                required
                value={details}
                onChange={(e) => setDetails(e.target.value)}
                placeholder="List features, pricing details, or discount codes..."
                className={`w-full h-24 p-2.5 rounded-xl border focus:outline-none focus:ring-1 focus:ring-indigo-500 leading-relaxed ${
                  theme === "dark" ? "bg-zinc-950 border-zinc-800 text-white" : "bg-zinc-50 border-zinc-200 text-zinc-900"
                }`}
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow transition flex items-center justify-center gap-1.5"
              id="btn-marketing-generate"
            >
              {loading ? (
                <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <Wand2 className="w-3.5 h-3.5 animate-pulse" />
                  <span>Synthesize Campaign Copy</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Right column: Generated output pane */}
        <div className="lg:col-span-2 space-y-4">
          {output ? (
            <div className={`p-5 rounded-2xl border flex flex-col justify-between h-full ${
              theme === "dark" ? "bg-zinc-900 border-zinc-800" : "bg-white border-zinc-200 shadow-sm"
            }`}>
              <div className="space-y-4">
                <div className="flex items-center justify-between border-b pb-2">
                  <h4 className="text-[10px] font-bold text-indigo-500 uppercase tracking-widest font-mono flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-indigo-500 animate-pulse" />
                    <span>Copydeck ready</span>
                  </h4>

                  <button
                    onClick={copyToClipboard}
                    className="p-1.5 rounded-lg border border-zinc-200 dark:border-zinc-800 hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-500 transition inline-flex items-center gap-1 text-[11px] font-bold"
                    id="btn-copy-marketing"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? "Copied!" : "Copy Deck"}</span>
                  </button>
                </div>

                <div className={`p-4 rounded-xl border text-xs font-mono leading-relaxed space-y-3 whitespace-pre-line ${
                  theme === "dark" ? "bg-zinc-950/60 border-zinc-800 text-zinc-200" : "bg-zinc-50 border-zinc-150 text-zinc-800"
                }`}>
                  {output}
                </div>
              </div>

              <div className="mt-4 pt-3.5 border-t border-zinc-200 dark:border-zinc-800 text-[10px] text-zinc-500 flex items-center gap-1">
                <Share2 className="w-3.5 h-3.5" />
                <span>Format validated for copydeck release. Ready to copy and paste.</span>
              </div>
            </div>
          ) : (
            <div className={`p-8 rounded-2xl border text-center h-full flex flex-col items-center justify-center space-y-3 ${
              theme === "dark" ? "bg-zinc-900 border-zinc-800 text-zinc-400" : "bg-white border-zinc-200 shadow-sm text-zinc-500"
            }`}>
              <Sparkles className="w-10 h-10 text-indigo-500/20" />
              <div>
                <h4 className="font-sans font-bold text-sm">Awaiting Briefing Synthesizers</h4>
                <p className="text-xs text-zinc-400 mt-1">Configure your product parameters and click Generate. Gemini will structure professional campaign frameworks.</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
