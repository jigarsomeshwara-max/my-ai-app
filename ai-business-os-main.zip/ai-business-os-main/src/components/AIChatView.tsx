import React, { useState, useRef, useEffect } from "react";
import { ChatMessage } from "../types";
import { Send, Bot, User, Trash2, Key, Info, HelpCircle } from "lucide-react";

interface AIChatViewProps {
  chatHistory: ChatMessage[];
  onAddMessage: (msg: ChatMessage) => void;
  onClearHistory: () => void;
  theme: "light" | "dark";
}

export default function AIChatView({
  chatHistory,
  onAddMessage,
  onClearHistory,
  theme,
}: AIChatViewProps) {
  const [inputText, setInputText] = useState("");
  const [generating, setGenerating] = useState(false);
  const [apiKeyWarning, setApiKeyWarning] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [chatHistory, generating]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || generating) return;

    const userMsg: ChatMessage = {
      id: "msg-" + Date.now(),
      sender: "user",
      text: inputText,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    onAddMessage(userMsg);
    setInputText("");
    setGenerating(true);
    setApiKeyWarning(false);

    try {
      const response = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: userMsg.text,
          history: chatHistory,
        }),
      });

      const data = await response.json();
      setGenerating(false);

      if (!response.ok || !data.success) {
        if (data.error === "GEMINI_API_KEY_MISSING") {
          setApiKeyWarning(true);
        }
      }

      const aiMsg: ChatMessage = {
        id: "msg-" + Date.now() + "-ai",
        sender: "ai",
        text: data.text || "I was unable to process that. Please check your system configuration.",
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      };
      onAddMessage(aiMsg);
    } catch (err) {
      setGenerating(false);
      onAddMessage({
        id: "msg-" + Date.now() + "-err",
        sender: "ai",
        text: "Error calling server endpoint. Is the dev server running? Fallback simulated text:\n\nHello! How can I assist you with your business cashflows or GST configuration today?",
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      });
    }
  };

  const PRESET_PROMPTS = [
    "Draft a GST invoice checklist for SaaS",
    "How should I track tax-deductible SaaS operations?",
    "Generate a cold follow-up script for corporate leads",
  ];

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden border rounded-2xl bg-zinc-950/20">
      {/* Chat header */}
      <div className={`p-4 border-b flex items-center justify-between ${
        theme === "dark" ? "bg-zinc-900/90 border-zinc-800" : "bg-white border-zinc-200"
      }`}>
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-indigo-600/10 text-indigo-500 flex items-center justify-center border border-indigo-500/20">
            <Bot className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h3 className="font-sans font-bold text-sm tracking-tight leading-none">AI Business Co-Pilot</h3>
            <span className="text-[10px] text-emerald-500 font-bold tracking-wider font-mono">ONLINE & READY</span>
          </div>
        </div>

        <button
          onClick={onClearHistory}
          disabled={chatHistory.length === 0}
          className="p-2 rounded-lg text-zinc-400 hover:text-rose-500 hover:bg-rose-500/10 transition disabled:opacity-40"
          title="Clear Chat Logs"
          id="btn-clear-chat"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>

      {/* Messages thread */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {chatHistory.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-4">
            <div className="w-12 h-12 rounded-full bg-indigo-500/10 text-indigo-500 flex items-center justify-center border border-indigo-500/20">
              <Bot className="w-6 h-6" />
            </div>
            <div className="max-w-sm space-y-1">
              <h4 className="font-sans font-bold text-sm">Consult Operational AI</h4>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Consult on bookkeeping strategies, GST compliant structures, enterprise contracts, and pitch optimization.
              </p>
            </div>

            <div className="grid grid-cols-1 gap-2 max-w-sm w-full mt-4">
              {PRESET_PROMPTS.map((prompt, i) => (
                <button
                  key={i}
                  onClick={() => setInputText(prompt)}
                  className={`text-[11px] font-medium p-2.5 rounded-xl border text-left transition hover:border-indigo-500/30 hover:bg-indigo-500/5 ${
                    theme === "dark" 
                      ? "bg-zinc-900 border-zinc-800 text-zinc-300" 
                      : "bg-white border-zinc-200 text-zinc-600"
                  }`}
                  id={`btn-preset-prompt-${i}`}
                >
                  {prompt}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {chatHistory.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-3 max-w-[85%] ${
                  msg.sender === "user" ? "ml-auto flex-row-reverse" : ""
                }`}
              >
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 border ${
                  msg.sender === "user" 
                    ? "bg-indigo-600 border-indigo-500 text-white" 
                    : "bg-zinc-800 border-zinc-700 text-indigo-400"
                }`}>
                  {msg.sender === "user" ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                </div>

                <div className={`p-3.5 rounded-2xl text-xs leading-relaxed space-y-1.5 ${
                  msg.sender === "user"
                    ? "bg-indigo-600 text-white"
                    : theme === "dark" 
                      ? "bg-zinc-900 border border-zinc-800 text-zinc-200" 
                      : "bg-white border border-zinc-200 text-zinc-800"
                }`}>
                  <p className="whitespace-pre-line">{msg.text}</p>
                  <span className={`block text-[8px] text-right font-mono font-medium ${
                    msg.sender === "user" ? "text-indigo-200" : "text-zinc-500"
                  }`}>
                    {msg.timestamp}
                  </span>
                </div>
              </div>
            ))}

            {generating && (
              <div className="flex gap-3 max-w-[85%]">
                <div className="w-8 h-8 rounded-lg bg-zinc-800 border border-zinc-700 text-indigo-400 flex items-center justify-center">
                  <Bot className="w-4 h-4 animate-bounce" />
                </div>
                <div className={`p-4 rounded-2xl border ${
                  theme === "dark" ? "bg-zinc-900 border-zinc-800" : "bg-white border-zinc-200"
                }`}>
                  <div className="flex items-center gap-1.5">
                    <span className="w-2 h-2 bg-indigo-500 rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                    <span className="w-2 h-2 bg-indigo-500 rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                    <span className="w-2 h-2 bg-indigo-500 rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {apiKeyWarning && (
        <div className={`mx-4 mb-2 p-3 rounded-xl border flex gap-2 text-xs transition ${
          theme === "dark" ? "bg-amber-500/10 border-amber-500/20 text-amber-400" : "bg-amber-50 border-amber-200 text-amber-800"
        }`}>
          <Key className="w-4 h-4 flex-shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h5 className="font-bold leading-none">Simulator Mode Active</h5>
            <p className="text-[10px] leading-relaxed text-zinc-500 dark:text-zinc-400">
              Your server doesn't have a valid <strong>GEMINI_API_KEY</strong> set. I am using our offline logic sandbox to continue helping you. Add your key in the <strong>Settings &gt; Secrets</strong> panel.
            </p>
          </div>
        </div>
      )}

      {/* Input container */}
      <form onSubmit={handleSend} className={`p-3 border-t flex gap-2 ${
        theme === "dark" ? "bg-zinc-900/40 border-zinc-800" : "bg-zinc-50 border-zinc-200"
      }`}>
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="Ask AI OS about SAC codes, GST filing, CRM tactics..."
          className={`flex-1 text-xs px-3.5 py-2.5 rounded-xl border focus:outline-none focus:ring-1 focus:ring-indigo-600 transition ${
            theme === "dark" ? "bg-zinc-950 border-zinc-800 text-white" : "bg-white border-zinc-200 text-zinc-950"
          }`}
          disabled={generating}
        />
        <button
          type="submit"
          disabled={!inputText.trim() || generating}
          className="p-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl transition disabled:opacity-40 shadow-md shadow-indigo-600/10 flex items-center justify-center"
          id="btn-chat-send"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
}
