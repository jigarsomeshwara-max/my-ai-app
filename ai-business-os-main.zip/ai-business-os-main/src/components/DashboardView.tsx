import React, { useState } from "react";
import { Invoice, Expense, ClientCRM } from "../types";
import { 
  TrendingUp, TrendingDown, DollarSign, Users, Briefcase, 
  ArrowUpRight, Clock, ShieldCheck, Zap, Receipt, AlertCircle 
} from "lucide-react";

interface DashboardViewProps {
  invoices: Invoice[];
  expenses: Expense[];
  clients: ClientCRM[];
  onNavigate: (tab: string) => void;
  theme: "light" | "dark";
}

export default function DashboardView({
  invoices,
  expenses,
  clients,
  onNavigate,
  theme,
}: DashboardViewProps) {
  const [hoveredDataIndex, setHoveredDataIndex] = useState<number | null>(null);

  // --- Calculations ---
  const totalRevenue = invoices
    .filter(inv => inv.status === "Paid")
    .reduce((sum, inv) => sum + inv.total, 0);

  const totalOutstanding = invoices
    .filter(inv => inv.status === "Unpaid" || inv.status === "Overdue")
    .reduce((sum, inv) => sum + inv.total, 0);

  const totalExpenses = expenses.reduce((sum, exp) => sum + exp.amount, 0);
  const netProfit = totalRevenue - totalExpenses;
  const activeLeadsCount = clients.filter(c => c.status !== "Closed").length;

  // --- SVG Chart Data Setup ---
  // Simulated monthly timeline from Jan to Jun
  const chartData = [
    { name: "Jan", sales: 45000, expenses: 15000 },
    { name: "Feb", sales: 78000, expenses: 22000 },
    { name: "Mar", sales: 112000, expenses: 31000 },
    { name: "Apr", sales: 95000, expenses: 28000 },
    { name: "May", sales: 135000, expenses: 42000 },
    { name: "Jun", sales: 168000, expenses: 45000 },
  ];

  const maxVal = 200000;
  const chartHeight = 160;
  const chartWidth = 500;

  const getCoordinates = (index: number, value: number) => {
    const x = (index / (chartData.length - 1)) * (chartWidth - 40) + 20;
    const y = chartHeight - (value / maxVal) * (chartHeight - 40) - 20;
    return { x, y };
  };

  // Build SVG Paths
  const salesPoints = chartData.map((d, i) => getCoordinates(i, d.sales));
  const expensePoints = chartData.map((d, i) => getCoordinates(i, d.expenses));

  const salesPath = salesPoints.reduce((path, p, i) => 
    i === 0 ? `M ${p.x} ${p.y}` : `${path} L ${p.x} ${p.y}`, ""
  );

  const expensePath = expensePoints.reduce((path, p, i) => 
    i === 0 ? `M ${p.x} ${p.y}` : `${path} L ${p.x} ${p.y}`, ""
  );

  const salesAreaPath = `${salesPath} L ${salesPoints[salesPoints.length - 1].x} ${chartHeight - 20} L ${salesPoints[0].x} ${chartHeight - 20} Z`;
  const expenseAreaPath = `${expensePath} L ${expensePoints[expensePoints.length - 1].x} ${chartHeight - 20} L ${expensePoints[0].x} ${chartHeight - 20} Z`;

  return (
    <div className="space-y-6 flex-1 overflow-y-auto pr-1">
      {/* Dynamic Greet banner */}
      <div className={`p-6 rounded-2xl border flex flex-col md:flex-row md:items-center justify-between gap-4 transition-all ${
        theme === "dark" 
          ? "bg-gradient-to-r from-indigo-950/40 via-zinc-900 to-zinc-900 border-zinc-800" 
          : "bg-gradient-to-r from-indigo-50/60 via-white to-white border-zinc-200"
      }`}>
        <div className="space-y-1">
          <h2 className="text-xl md:text-2xl font-sans font-extrabold tracking-tight">
            Financial Dashboard
          </h2>
          <p className="text-xs text-zinc-500">
            Automating your billing, customer acquisitions, and generative SEO pipelines in real time.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="flex h-2.5 w-2.5 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
          </span>
          <span className="text-xs font-mono font-semibold tracking-wider text-emerald-500 bg-emerald-500/10 px-2.5 py-1 rounded-full border border-emerald-500/20 uppercase">
            LIVE SYSTEM NODES OK
          </span>
        </div>
      </div>

      {/* KPI Stats Widgets */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Net Revenue */}
        <div className={`p-4 rounded-2xl border transition-all hover:scale-[1.01] ${
          theme === "dark" ? "bg-zinc-900 border-zinc-800" : "bg-white border-zinc-200 shadow-sm"
        }`}>
          <div className="flex items-center justify-between mb-3">
            <span className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">Net Profit Margin</span>
            <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-500">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <h3 className="text-lg md:text-2xl font-bold font-sans">
            ₹{(netProfit).toLocaleString("en-IN")}
          </h3>
          <div className="flex items-center gap-1 text-emerald-500 text-[10px] font-bold mt-1.5">
            <TrendingUp className="w-3.5 h-3.5" />
            <span>+14.2% from last month</span>
          </div>
        </div>

        {/* Paid Revenue */}
        <div className={`p-4 rounded-2xl border transition-all hover:scale-[1.01] ${
          theme === "dark" ? "bg-zinc-900 border-zinc-800" : "bg-white border-zinc-200 shadow-sm"
        }`}>
          <div className="flex items-center justify-between mb-3">
            <span className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">Invoiced Revenue</span>
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-500">
              <ShieldCheck className="w-4 h-4" />
            </div>
          </div>
          <h3 className="text-lg md:text-2xl font-bold font-sans">
            ₹{totalRevenue.toLocaleString("en-IN")}
          </h3>
          <div className="flex items-center gap-1 text-zinc-400 text-[10px] mt-1.5">
            <Clock className="w-3.5 h-3.5 text-amber-500" />
            <span>₹{totalOutstanding.toLocaleString("en-IN")} Outstanding</span>
          </div>
        </div>

        {/* Operating Costs */}
        <div className={`p-4 rounded-2xl border transition-all hover:scale-[1.01] ${
          theme === "dark" ? "bg-zinc-900 border-zinc-800" : "bg-white border-zinc-200 shadow-sm"
        }`}>
          <div className="flex items-center justify-between mb-3">
            <span className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">Total Expenses</span>
            <div className="p-2 rounded-xl bg-rose-500/10 text-rose-500">
              <TrendingDown className="w-4 h-4" />
            </div>
          </div>
          <h3 className="text-lg md:text-2xl font-bold font-sans">
            ₹{totalExpenses.toLocaleString("en-IN")}
          </h3>
          <div className="flex items-center gap-1 text-rose-500 text-[10px] font-bold mt-1.5">
            <TrendingDown className="w-3.5 h-3.5" />
            <span>-2.4% below budget target</span>
          </div>
        </div>

        {/* CRM Portfolio */}
        <div className={`p-4 rounded-2xl border transition-all hover:scale-[1.01] ${
          theme === "dark" ? "bg-zinc-900 border-zinc-800" : "bg-white border-zinc-200 shadow-sm"
        }`}>
          <div className="flex items-center justify-between mb-3">
            <span className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">Active Deals</span>
            <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-500">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <h3 className="text-lg md:text-2xl font-bold font-sans">
            {activeLeadsCount} Leads
          </h3>
          <div className="flex items-center gap-1 text-cyan-500 text-[10px] font-bold mt-1.5">
            <Zap className="w-3.5 h-3.5 animate-pulse" />
            <span>3 leads active in last 24h</span>
          </div>
        </div>
      </div>

      {/* Main Grid: interactive flow chart & live alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* cashflow SVG chart block */}
        <div className={`lg:col-span-2 p-5 rounded-2xl border flex flex-col justify-between ${
          theme === "dark" ? "bg-zinc-900 border-zinc-800" : "bg-white border-zinc-200 shadow-sm"
        }`}>
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-sans font-bold text-sm tracking-tight">Cashflow Reconciliations</h3>
              <p className="text-[11px] text-zinc-500">Reconciled Sales vs Overhead Expenses (YTD)</p>
            </div>
            {/* chart legend */}
            <div className="flex items-center gap-3 text-[10px] font-semibold">
              <div className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 rounded bg-indigo-600 inline-block" />
                <span>Sales</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 rounded bg-rose-500 inline-block" />
                <span>Expenses</span>
              </div>
            </div>
          </div>

          {/* SVG Canvas Area */}
          <div className="relative w-full h-[180px] mt-2 select-none">
            <svg 
              viewBox={`0 0 ${chartWidth} ${chartHeight}`} 
              className="w-full h-full overflow-visible"
              preserveAspectRatio="none"
            >
              {/* grid background lines */}
              <line x1="20" y1="20" x2={chartWidth - 20} y2="20" stroke={theme === "dark" ? "#1e1b4b" : "#e0e7ff"} strokeDasharray="3 3" />
              <line x1="20" y1="70" x2={chartWidth - 20} y2="70" stroke={theme === "dark" ? "#1e1b4b" : "#e0e7ff"} strokeDasharray="3 3" />
              <line x1="20" y1="120" x2={chartWidth - 20} y2="120" stroke={theme === "dark" ? "#1e1b4b" : "#e0e7ff"} strokeDasharray="3 3" />
              <line x1="20" y1="140" x2={chartWidth - 20} y2="140" stroke={theme === "dark" ? "#27272a" : "#e4e4e7"} />

              {/* Area shadows */}
              <path d={salesAreaPath} fill="url(#salesGrad)" opacity="0.12" />
              <path d={expenseAreaPath} fill="url(#expenseGrad)" opacity="0.08" />

              {/* Gradients */}
              <defs>
                <linearGradient id="salesGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#4f46e5" />
                  <stop offset="100%" stopColor="#4f46e5" stopOpacity="0" />
                </linearGradient>
                <linearGradient id="expenseGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#f43f5e" />
                  <stop offset="100%" stopColor="#f43f5e" stopOpacity="0" />
                </linearGradient>
              </defs>

              {/* curves */}
              <path d={salesPath} fill="none" stroke="#4f46e5" strokeWidth="3" strokeLinecap="round" />
              <path d={expensePath} fill="none" stroke="#f43f5e" strokeWidth="2.5" strokeLinecap="round" strokeDasharray="4 2" />

              {/* Interactive nodes and tooltip markers */}
              {salesPoints.map((p, i) => (
                <g key={i} onMouseEnter={() => setHoveredDataIndex(i)} onMouseLeave={() => setHoveredDataIndex(null)} className="cursor-pointer">
                  {/* sales circle hover rings */}
                  <circle cx={p.x} cy={p.y} r={hoveredDataIndex === i ? 7 : 4} fill="#4f46e5" stroke="#ffffff" strokeWidth="1.5" />
                  {/* expense points */}
                  <circle cx={expensePoints[i].x} cy={expensePoints[i].y} r={hoveredDataIndex === i ? 6 : 3.5} fill="#f43f5e" stroke="#ffffff" strokeWidth="1.5" />
                </g>
              ))}

              {/* X axis month labels */}
              {chartData.map((d, i) => {
                const x = (i / (chartData.length - 1)) * (chartWidth - 40) + 20;
                return (
                  <text 
                    key={i} 
                    x={x} 
                    y="155" 
                    textAnchor="middle" 
                    fill={theme === "dark" ? "#71717a" : "#71717a"} 
                    className="text-[9px] font-mono font-bold"
                  >
                    {d.name}
                  </text>
                );
              })}
            </svg>

            {/* Custom Interactive Tooltip Hover Overlay */}
            {hoveredDataIndex !== null && (
              <div 
                className={`absolute p-2.5 rounded-xl border shadow-lg text-[10px] font-mono leading-tight z-30 pointer-events-none transition-all duration-100 ${
                  theme === "dark" ? "bg-zinc-950 border-zinc-800 text-zinc-300" : "bg-white border-zinc-200 text-zinc-700"
                }`}
                style={{
                  left: `${(hoveredDataIndex / (chartData.length - 1)) * 80 + 10}%`,
                  bottom: "70px",
                }}
              >
                <div className="font-bold border-b border-zinc-200 dark:border-zinc-800 pb-1 mb-1 text-zinc-400 uppercase tracking-widest">
                  {chartData[hoveredDataIndex].name} Reconciliation
                </div>
                <div className="flex justify-between gap-4">
                  <span>Sales Revenue:</span>
                  <strong className="text-indigo-500">₹{chartData[hoveredDataIndex].sales.toLocaleString("en-IN")}</strong>
                </div>
                <div className="flex justify-between gap-4 mt-0.5">
                  <span>Operating Costs:</span>
                  <strong className="text-rose-500">₹{chartData[hoveredDataIndex].expenses.toLocaleString("en-IN")}</strong>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Hot Lead follow-up recommendations */}
        <div className={`p-5 rounded-2xl border flex flex-col justify-between ${
          theme === "dark" ? "bg-zinc-900 border-zinc-800" : "bg-white border-zinc-200 shadow-sm"
        }`}>
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-sans font-bold text-sm tracking-tight flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 text-amber-500 animate-pulse" />
                <span>Urgent CRM Action</span>
              </h3>
              <span className="text-[9px] font-semibold text-zinc-400 uppercase font-mono tracking-wider">Acquisitions</span>
            </div>

            <div className="space-y-3.5">
              {clients.slice(0, 2).map((client) => (
                <div 
                  key={client.id}
                  className={`p-3.5 rounded-xl border flex flex-col gap-2 transition hover:scale-[1.01] ${
                    theme === "dark" ? "bg-zinc-950 border-zinc-800" : "bg-zinc-50 border-zinc-200"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-xs font-bold leading-none">{client.name}</h4>
                      <span className="text-[9px] font-mono text-zinc-400 mt-1 inline-block">{client.company}</span>
                    </div>
                    <span className="text-[10px] font-mono font-bold text-amber-500 bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded-full">
                      {client.status}
                    </span>
                  </div>
                  <p className="text-[10.5px] text-zinc-500 leading-relaxed italic">
                    "{client.notes.slice(0, 75)}..."
                  </p>
                  <button
                    onClick={() => onNavigate("crm")}
                    className="text-[10px] text-indigo-500 font-bold flex items-center gap-0.5 hover:underline text-left mt-1 self-start"
                  >
                    <span>Fetch AI Action Script</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={() => onNavigate("crm")}
            className="w-full mt-4 py-2 rounded-xl text-center text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white transition flex items-center justify-center gap-1.5 shadow shadow-indigo-600/10"
          >
            <span>Open Customer CRM Workspace</span>
          </button>
        </div>
      </div>

      {/* Operational Task Grid */}
      <div className="space-y-3">
        <h4 className="text-xs font-bold uppercase tracking-widest text-zinc-400 font-mono">Operational Modules Quick Nodes</h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          <button 
            onClick={() => onNavigate("ai-chat")}
            className={`p-4 rounded-2xl border text-left flex flex-col justify-between gap-4 transition hover:bg-indigo-500/5 hover:border-indigo-500/30 group ${
              theme === "dark" ? "bg-zinc-900 border-zinc-800" : "bg-white border-zinc-200 shadow-sm"
            }`}
          >
            <div className="w-8 h-8 rounded-lg bg-indigo-500/10 text-indigo-500 flex items-center justify-center group-hover:bg-indigo-600 group-hover:text-white transition">
              <Zap className="w-4 h-4" />
            </div>
            <div>
              <h5 className="text-xs font-bold leading-none">Consult AI copilot</h5>
              <p className="text-[10px] text-zinc-400 mt-1 leading-tight">Financial advice & planning</p>
            </div>
          </button>

          <button 
            onClick={() => onNavigate("invoices")}
            className={`p-4 rounded-2xl border text-left flex flex-col justify-between gap-4 transition hover:bg-emerald-500/5 hover:border-emerald-500/30 group ${
              theme === "dark" ? "bg-zinc-900 border-zinc-800" : "bg-white border-zinc-200 shadow-sm"
            }`}
          >
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-500 flex items-center justify-center group-hover:bg-emerald-600 group-hover:text-white transition">
              <Receipt className="w-4 h-4" />
            </div>
            <div>
              <h5 className="text-xs font-bold leading-none">Generate GST Invoice</h5>
              <p className="text-[10px] text-zinc-400 mt-1 leading-tight">Auto-compute SAC/GST</p>
            </div>
          </button>

          <button 
            onClick={() => onNavigate("marketing")}
            className={`p-4 rounded-2xl border text-left flex flex-col justify-between gap-4 transition hover:bg-rose-500/5 hover:border-rose-500/30 group ${
              theme === "dark" ? "bg-zinc-900 border-zinc-800" : "bg-white border-zinc-200 shadow-sm"
            }`}
          >
            <div className="w-8 h-8 rounded-lg bg-rose-500/10 text-rose-500 flex items-center justify-center group-hover:bg-rose-600 group-hover:text-white transition">
              <Briefcase className="w-4 h-4" />
            </div>
            <div>
              <h5 className="text-xs font-bold leading-none">Marketing Copywriter</h5>
              <p className="text-[10px] text-zinc-400 mt-1 leading-tight">Instant script creation</p>
            </div>
          </button>

          <button 
            onClick={() => onNavigate("sdk")}
            className={`p-4 rounded-2xl border text-left flex flex-col justify-between gap-4 transition hover:bg-cyan-500/5 hover:border-cyan-500/30 group ${
              theme === "dark" ? "bg-zinc-900 border-zinc-800" : "bg-white border-zinc-200 shadow-sm"
            }`}
          >
            <div className="w-8 h-8 rounded-lg bg-cyan-500/10 text-cyan-500 flex items-center justify-center group-hover:bg-cyan-600 group-hover:text-white transition">
              <Briefcase className="w-4 h-4" />
            </div>
            <div>
              <h5 className="text-xs font-bold leading-none">Developer SDK Export</h5>
              <p className="text-[10px] text-zinc-400 mt-1 leading-tight">Flutter files & Supabase SQL</p>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
}
