import React, { useState } from "react";
import { PushNotification } from "../types";
import { Bell, BellOff, Check, Trash2, Send, ShieldAlert, Sparkles, AlertCircle } from "lucide-react";

interface NotificationsPanelProps {
  notifications: PushNotification[];
  onMarkRead: (id: string) => void;
  onClearAll: () => void;
  onSimulateNotification: (title: string, body: string, type: "crm" | "billing" | "security" | "system") => void;
  theme: "light" | "dark";
}

export default function NotificationsPanel({
  notifications,
  onMarkRead,
  onClearAll,
  onSimulateNotification,
  theme,
}: NotificationsPanelProps) {
  const [testTitle, setTestTitle] = useState("CRM Lead Closed");
  const [testBody, setTestBody] = useState("Aarav Sharma has authorized their custom ₹1,25,000 SaaS retainer invoice.");
  const [testType, setTestType] = useState<any>("crm");

  const triggerSimulation = (e: React.FormEvent) => {
    e.preventDefault();
    onSimulateNotification(testTitle, testBody, testType);
    setTestTitle("");
    setTestBody("");
  };

  const getIcon = (type: string) => {
    switch (type) {
      case "crm":
        return <Sparkles className="w-4 h-4 text-cyan-500" />;
      case "billing":
        return <Check className="w-4 h-4 text-emerald-500" />;
      case "security":
        return <ShieldAlert className="w-4 h-4 text-rose-500" />;
      default:
        return <AlertCircle className="w-4 h-4 text-indigo-500" />;
    }
  };

  return (
    <div className="flex-1 overflow-y-auto space-y-6 pr-1 h-full">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-sans font-extrabold tracking-tight">FCM Push Notifications</h2>
          <p className="text-xs text-zinc-500 font-medium">Audit real-time system alerts, CRM updates, and transaction webhooks.</p>
        </div>

        <button
          onClick={onClearAll}
          disabled={notifications.length === 0}
          className="px-3 py-1.5 border border-rose-500/20 hover:bg-rose-500/10 text-rose-500 rounded-xl text-xs font-semibold flex items-center gap-1 transition disabled:opacity-40"
          id="btn-clear-notifications"
        >
          <Trash2 className="w-3.5 h-3.5" />
          <span>Clear All Alerts</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left column: Trigger Sandbox push simulation */}
        <div className={`p-5 rounded-2xl border space-y-4 h-fit ${
          theme === "dark" ? "bg-zinc-900 border-zinc-800" : "bg-white border-zinc-200 shadow-sm"
        }`}>
          <div className="flex items-center gap-1.5">
            <Bell className="w-4.5 h-4.5 text-indigo-500 animate-swing" />
            <h3 className="font-sans font-extrabold text-sm tracking-tight">Push Token Simulator</h3>
          </div>
          
          <p className="text-[10px] text-zinc-500 leading-relaxed">
            Test device notifications by simulating live Firebase Cloud Messaging (FCM) or Apple APNS slide-down banners.
          </p>

          <form onSubmit={triggerSimulation} className="space-y-4 text-xs">
            <div>
              <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                Notification Type / Category
              </label>
              <select
                value={testType}
                onChange={(e) => setTestType(e.target.value as any)}
                className={`w-full p-2 rounded-xl border focus:outline-none ${
                  theme === "dark" ? "bg-zinc-950 border-zinc-800 text-white" : "bg-zinc-50 border-zinc-200 text-zinc-900"
                }`}
              >
                <option value="crm">CRM Prospect Alerts</option>
                <option value="billing">Billing & Razorpay Webhooks</option>
                <option value="security">Security & Auth Logs</option>
                <option value="system">Core System Alerts</option>
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                Notification Title
              </label>
              <input
                type="text"
                required
                value={testTitle}
                onChange={(e) => setTestTitle(e.target.value)}
                placeholder="e.g. Transaction Succeeded"
                className={`w-full p-2 rounded-xl border focus:outline-none ${
                  theme === "dark" ? "bg-zinc-950 border-zinc-800 text-white" : "bg-zinc-50 border-zinc-200 text-zinc-900"
                }`}
              />
            </div>

            <div>
              <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                Body Copy Description
              </label>
              <textarea
                required
                value={testBody}
                onChange={(e) => setTestBody(e.target.value)}
                placeholder="Message displayed in the notification banner..."
                className={`w-full h-16 p-2 rounded-xl border focus:outline-none leading-relaxed ${
                  theme === "dark" ? "bg-zinc-950 border-zinc-800 text-white" : "bg-zinc-50 border-zinc-200 text-zinc-900"
                }`}
              />
            </div>

            <button
              type="submit"
              className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow transition flex items-center justify-center gap-1.5"
              id="btn-simulate-notify"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Broadcast Push Banner</span>
            </button>
          </form>
        </div>

        {/* Right column: Notification logs history list */}
        <div className={`lg:col-span-2 border rounded-2xl overflow-hidden ${
          theme === "dark" ? "bg-zinc-900 border-zinc-800" : "bg-white border-zinc-200 shadow-sm"
        }`}>
          <div className="p-4 border-b border-zinc-200 dark:border-zinc-800 flex items-center gap-2">
            <Bell className="w-4.5 h-4.5 text-indigo-500" />
            <h3 className="font-sans font-bold text-xs uppercase tracking-wider text-zinc-400">Push Alert Ledger</h3>
          </div>

          {notifications.length === 0 ? (
            <div className="p-12 text-center text-zinc-500 text-xs space-y-1">
              <BellOff className="w-8 h-8 text-zinc-400 mx-auto opacity-40 mb-2" />
              <p className="font-bold">Device ledger is clear</p>
              <p className="text-[10px] text-zinc-400">Broadcast a test push banner from the Token Simulator.</p>
            </div>
          ) : (
            <div className="divide-y divide-zinc-200 dark:divide-zinc-800">
              {notifications.map((notif) => (
                <div
                  key={notif.id}
                  className={`p-4 flex items-start gap-3 transition ${
                    !notif.read 
                      ? theme === "dark" ? "bg-indigo-950/10" : "bg-indigo-50/30" 
                      : "hover:bg-zinc-500/5"
                  }`}
                >
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center border flex-shrink-0 ${
                    theme === "dark" ? "bg-zinc-950 border-zinc-800" : "bg-zinc-50 border-zinc-250"
                  }`}>
                    {getIcon(notif.type)}
                  </div>

                  <div className="flex-1 space-y-1">
                    <div className="flex items-center justify-between gap-2">
                      <h4 className={`text-xs ${!notif.read ? "font-bold" : "font-semibold"}`}>{notif.title}</h4>
                      <span className="text-[9px] font-mono font-bold text-zinc-400">{notif.time}</span>
                    </div>
                    <p className="text-[11px] text-zinc-500 leading-normal">{notif.body}</p>
                  </div>

                  {!notif.read && (
                    <button
                      onClick={() => onMarkRead(notif.id)}
                      className="p-1 rounded bg-emerald-500/10 border border-emerald-500/20 text-emerald-500 text-[10px] font-bold"
                      title="Mark as Read"
                    >
                      Dismiss
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
