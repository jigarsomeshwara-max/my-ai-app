export interface UserProfile {
  id: string;
  email: string;
  name: string;
  avatar: string;
  plan: "Free" | "Pro" | "Enterprise";
  companyName: string;
}

export interface ClientCRM {
  id: string;
  name: string;
  email: string;
  phone: string;
  company: string;
  value: number;
  status: "Lead" | "Contacted" | "Warm" | "Qualified" | "Closed";
  notes: string;
  lastActive: string;
  insights?: string;
}

export interface InvoiceItem {
  id: string;
  description: string;
  quantity: number;
  rate: number;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  clientName: string;
  clientEmail: string;
  clientGstin?: string;
  date: string;
  dueDate: string;
  items: InvoiceItem[];
  gstRate: number; // e.g. 18%
  discount: number; // e.g. amount or percentage
  status: "Paid" | "Unpaid" | "Overdue";
  total: number;
}

export interface Expense {
  id: string;
  amount: number;
  category: string;
  vendor: string;
  date: string;
  gstRate: number;
  gstAmount: number;
  description: string;
  tags: string[];
}

export interface ChatMessage {
  id: string;
  sender: "user" | "ai";
  text: string;
  timestamp: string;
}

export interface PushNotification {
  id: string;
  title: string;
  body: string;
  time: string;
  read: boolean;
  type: "crm" | "billing" | "security" | "system";
}

export interface SystemLog {
  id: string;
  timestamp: string;
  type: "info" | "warning" | "success" | "error";
  service: string;
  message: string;
}
